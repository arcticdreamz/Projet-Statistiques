clear all;
close all;

Exam = xlsread('Proba1ereSess20122013.xls');

%% 1.b) Les trois moyennes, les trois m�dianes, les trois modes et les trois


% Les trois moyennes

fprintf('La moyenne pour la question d Exercice 1 vaud: %f/20 \n\n',mean(Exam(:,8)));
E1moy=mean(Exam(:,8));
fprintf('La moyenne pour la question d Exercice 2 vaud: %f/20 \n\n',mean(Exam(:,9)));
E2moy=mean(Exam(:,9));
fprintf('La moyenne pour la question d Excercice 3 vaud: %f/20 \n\n',mean(Exam(:,10)));
E3moy=mean(Exam(:,10));

% Les trois m�dianes
% Les trois modes
% Les trois �cart types

Vectinit=zeros(1,length(Exam));
for i=1:1:length(Exam)
    Vectinit(i)=(Exam(i,8)-E1moy)^2;
end 
SigE1=sqrt(mean(Vectinit));
fprintf('La m�diane, le mode et l Ecart type pour la question de Exercice 1 valent (respectivement): \n %f \n %f \n %f \n',median(Exam(:,8)),mode(Exam(:,8)),sqrt(mean(Vectinit)));
Vectinit=zeros(1,length(Exam));
for i=1:1:length(Exam)
    Vectinit(i)=(Exam(i,9)-E2moy)^2;
end 
SigE2=sqrt(mean(Vectinit));
fprintf('La m�diane, le mode et l Ecart type pour la question de Exercice 2 valent (respectivement): \n %f \n %f \n %f \n',median(Exam(:,9)),mode(Exam(:,9)),sqrt(mean(Vectinit)));
Vectinit=zeros(1,length(Exam));
for i=1:1:length(Exam)
    Vectinit(i)=(Exam(i,10)-E3moy)^2;
end 
SigE3=sqrt(mean(Vectinit));
fprintf('La m�diane, le mode et l Ecart type pour la question de Exercice 3 valent (respectivement): \n %f \n %f \n %f \n',median(Exam(:,10)),mode(Exam(:,10)),sqrt(mean(Vectinit)));

% Lois normale

%Th�orie 1
n1=148;

for i=1:1:20;
    n(i)=n1/(sqrt(2*pi)*SigE1)*exp(-(i-E1moy)^2/(2*SigE1^2));
end
x=1:1:20;
hist(Exam(:,8),x)
hold on
plot(x,n)
title('Lois normale-Histogramme pour Exerice 1');
figure

n1=149;

for i=1:1:20;
    n(i)=n1/(sqrt(2*pi)*SigE2)*exp(-(i-E2moy)^2/(2*SigE2^2));
end
x=1:1:20;
hist(Exam(:,9),x)
hold on
plot(x,n)
title('Lois normale-Histogramme pour Exercice 2');
figure

n1=148;

for i=1:1:20;
    n(i)=n1/(sqrt(2*pi)*SigE3)*exp(-(i-E3moy)^2/(2*SigE3^2));
end
x=1:1:20;
hist(Exam(:,10),x)
hold on
plot(x,n)

title('Lois normale-Histogramme pour Exercice 3');


% Normaux pour Exercice 1
counter=0;
for i=1:148
    if Exam(i,8)<=E1moy+SigE1 && Exam(i,8)>=E1moy-SigE1
        counter=counter+1;
    end
end
fprintf('R�sultats normaux pour l exercice 1:[ %f ; %f ] \n\n',E1moy-SigE1,E1moy+SigE1);
fprintf('La proportion des gens qui sont normaux pour Exercice 1: %f %%\n \n',counter*100/148);
% Normaux pour Exercice 2
counter=0;
for i=1:148
    if Exam(i,9)<=E2moy+SigE2 && Exam(i,9)>=E2moy-SigE2
        counter=counter+1;
    end
end
fprintf('R�sultats normaux pour l exercice 2:[ %f ; %f ] \n\n',E2moy-SigE2,E2moy+SigE2);
fprintf('La proportion des gens qui sont normaux pour Exercice 2: %f %%\n \n',counter*100/148);

% Normaux pour Exercice 3
counter=0;
for i=1:148
    if Exam(i,10)<=E3moy+SigE3 && Exam(i,10)>=E3moy-SigE3
        counter=counter+1;
    end
end
fprintf('R�sultats normaux pour l exercice 3:[ %f ; %f ] \n\n',E3moy-SigE3,E3moy+SigE3);
fprintf('La proportion des gens qui sont normaux pour la Exercice 3: %f %%\n \n',counter*100/148);



















