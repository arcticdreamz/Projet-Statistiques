clear all;
close all;


Exam = xlsread('Proba1ereSess20122013.xls');
%% question 2.b. i et ii et iii 

for j=1:100
composante=1:1:length(Exam); % vecteur qui contient les lignes du tableau Exam
indice=randsample(composante,20,true);% Prend al�atoirement les indices du tableau

% Mettre les valeurs pour chaque Exam
for i=1:length(indice)
    VectExamExo1(i)=Exam(indice(i),8);
end

% Moyenne, m�diane, �cart-type

E1moy=mean(VectExamExo1);

Vectinit=zeros(1,length(indice));
for i=1:1:length(indice)
    Vectinit(i)=(VectExamExo1(i)-E1moy)^2;
end 
SigE1=sqrt(mean(Vectinit));

E1moy100(j)=E1moy;
E1median100(j)=median(VectExamExo1);
SigE1100(j)=SigE1;


end

fprintf(' la moyenne pour les nouvelles variable moyenne, mediane, �cart type de l exercice 1 valent:\n %f \n %f \n %f \n',mean(E1moy100),mean(E1median100),mean(SigE1100));

hist(E1moy100)
title('Moyennes des 100 �chantillons d un tirage de 20 �tudiants ');
figure
hist(E1median100)
title('Median des 100 �chantillons d un tirage de 20 �tudiants ');
figure
hist(SigE1100)
title('Ecart-type des 100 �chantillons d un tirage de 20 �tudiants ');

