clear all;
close all;

Exam = xlsread('Proba1ereSess20122013.xls');
%% 1.c) 4 boite � moustaches, donn�e ab�rante, quartile.
% Donn�es
Qp1=Exam(:,1);
Qp2=Exam(:,2);
Qp3=Exam(:,3);
Qp4=Exam(:,4);

boxplot(Qp1)
title('Boite � moustache Projet 1');
figure
Qp1q1x=quantile(Qp1,0.25); % Calcul du quartil Q1x
Qp1q3x=quantile(Qp1,0.75); % Calcul du quartil Q3x
fprintf(' Les quartiles pour le projet 1 sont: \n Q1x=%f \n Q3x=%f \n\n',Qp1q1x,Qp1q3x);

boxplot(Qp2)
title('Boite � moustache Projet 2');
figure
Qp2q1x=quantile(Qp2,0.25); % Calcul du quartil Q1x
Qp2q3x=quantile(Qp2,0.75); % Calcul du quartil Q3x
fprintf(' Les quartiles pour le projet 2 sont: \n Q1x=%f \n Q3x=%f \n\n',Qp2q1x,Qp2q3x);


boxplot(Qp3)
title('Boite � moustache Projet 3');
figure
Qp3q1x=quantile(Qp3,0.25); % Calcul du quartil Q1x
Qp3q3x=quantile(Qp3,0.75); % Calcul du quartil Q3x
fprintf(' Les quartiles pour le projet 3 sont: \n Q1x=%f \n Q3x=%f \n\n',Qp3q1x,Qp3q3x);


boxplot(Qp4)
title('Boite � moustache question projet 3');
Qp4q1x=quantile(Qp4,0.25); % Calcul du quartil Q1x
Qp4q3x=quantile(Qp4,0.75); % Calcul du quartil Q3x
fprintf(' Les quartiles pour la question du projet 3 poser a lexam sont: \n Q1x=%f \n Q3x=%f \n\n',Qp4q1x,Qp4q3x);

% Pour le reste voir Graphique