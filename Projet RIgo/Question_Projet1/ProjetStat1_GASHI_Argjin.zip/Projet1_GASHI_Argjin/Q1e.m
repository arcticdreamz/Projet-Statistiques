Exam = xlsread('Proba1ereSess20122013.xls');
%% 1.e)
% Donn�es

Qp3=Exam(:,3);
Qp4=Exam(:,4);
scatter(Qp3,Qp4)
xlabel('moyenne alg�brique du projet 3');
ylabel('moyenne alg�brique des questions de l examen: question sur le projet 3');
fprintf('on obtien un coefficient de corr�lation �gale �  %f \n ',corrcoef(Qp3,Qp4));