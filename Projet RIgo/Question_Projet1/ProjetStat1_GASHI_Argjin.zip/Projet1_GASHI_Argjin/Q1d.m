clear all;
close all;


Exam = xlsread('Proba1ereSess20122013.xls','199265_001');
%% 1.d)
% Deux variable

% Variable contenant la moyenne pour la th�orie de chaque �tudiant
Q=Exam;
 VarMoyTheoetud=zeros(1,length(Exam));
for i=1:1:length(Exam)
    VarMoyTheoetud(i)=(Q(i,5)+Q(i,6)+Q(i,7))/3;
end

% Variable contenant la moyenne pour les exercices de chaque �tudiant
 VarMoyExoetud=zeros(1,length(Exam));
for i=1:1:length(Exam)
    VarMoyExoetud(i)=(Q(i,8)+Q(i,9)+Q(i,10))/3;
end

n=148;

% Polygone de Fr�quence cumul�
cmpt=0;
for i=1:21;
    PolyFrqCumTheo(i)=length( find(i-1<=VarMoyTheoetud & VarMoyTheoetud<i))/n+cmpt;
    cmpt=PolyFrqCumTheo(i);
end
% Calcul des personne �tant compris en 12 et 15
PropEtudTheo=length(find(12<=VarMoyTheoetud & VarMoyTheoetud<=15))/n;

fprintf('La proportion des etudiants ayant entre 12  et 15 pour la th�orie est: \n %f %%  \n\n ', PropEtudTheo*100);
y=0:20;
plot(y,PolyFrqCumTheo)
title('Polygone de fr�quence cumul� pour la th�orie');
 figure
 cmpt=0;
for i=1:21;
    
    PolyFrqCumExo(i)=length( find(i-1<=VarMoyExoetud & VarMoyExoetud<i))/n+cmpt;
    cmpt=PolyFrqCumExo(i);
end
 
PropEtudExo=length(find(12<=VarMoyExoetud & VarMoyExoetud<=15))/n;
fprintf('La proportion des etudiants ayant entre 12 et 15 pour les exercices est: \n %f %% \n\n ', PropEtudExo*100);
plot(y,PolyFrqCumExo)
title('Polygone de fr�quence cumul� pour les exercices');
