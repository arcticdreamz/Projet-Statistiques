
clear all;
close all;
Q2aii;
%% Question 2.a.iii)
%% Je reprend un copier-coller de l'exercice 1.d pour pouvoir faire la distance de kolomogorov
Exam = xlsread('Proba1ereSess20122013.xls');
% Variable contenant la moyenne pour la th�orie de chaque �tudiant
Q=Exam;
 VarMoyTheoetud=zeros(1,length(Exam));
for i=1:1:length(Exam)
    VarMoyTheoetud(i)=(Q(i,5)+Q(i,6)+Q(i,7))/3;
end

n=148;
% Polygone de Fr�quence cumul� pour la th�orie
cmpt=0;
for i=1:21;
    PolyFrqCumTheo(i)=length( find(i-1<=VarMoyTheoetud & VarMoyTheoetud<i))/n+cmpt;
    cmpt=PolyFrqCumTheo(i);
end




%% Ici commence la vrai demande de l'exercice

for i=1:length(indice)
    VectQTheori1(i)=Exam(indice(i),5);
    VectQTheori2(i)=Exam(indice(i),6);
    VectQTheori3(i)=Exam(indice(i),7);
  
end

% Variable contenant la moyenne pour la th�orie de chaque �tudiant
 VarMoyTheoetud=zeros(1,length(indice));
for i=1:1:length(indice)
    VarMoyTheoetud(i)=(VectQTheori1(i)+VectQTheori2(i)+VectQTheori3(i))/3;
end
% Polygone de Fr�quence cumul� pour l'�chantillon

n=length(indice);
cmpt=0;
for i=1:21;
    PolyFrqCumTheoiid(i)=length( find(i-1<=VarMoyTheoetud & VarMoyTheoetud<i))/n+cmpt;
    cmpt=PolyFrqCumTheoiid(i);
end
x=0:20;
plot(x,PolyFrqCumTheo,'r')
hold on


plot(x,PolyFrqCumTheoiid)
title('Polygone de fr�quence cumul� pour la th�orie d un tirage de 20 �tudiants (en bleu) par rapport � la population (en rouge)');

% Calcule de la distance de Kolomogorov smirnov


DistKolSmir=abs(PolyFrqCumTheoiid-PolyFrqCumTheo);
%plot(x,DistKolSmir)

fprintf('La distance de Kolomogorov Smirnov trouver est: %f \n',max(DistKolSmir));
 