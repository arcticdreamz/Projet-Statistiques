close all;
clear all;

Exam = xlsread('Proba1ereSess20122013.xls');
%% question 2.a.i)

composante=1:1:length(Exam); % vecteur qui contient les lignes du tableau Exam

indice=randsample(composante,20,true);% Prend al�atoirement les indices du tableau
%indice=[113 31 101  49   3  97 108  83   137  78  26  144  71 47   9  69  54  44  71   71];

% Mettre les valeurs pour chaque Exam
for i=1:length(indice)
    VectExamExo1(i)=Exam(indice(i),8);
    VectExamExo2(i)=Exam(indice(i),9);
    VectExamExo3(i)=Exam(indice(i),10);
end

% Moyenne, m�diane, �cart-type

E1moy=mean(VectExamExo1);

E2moy=mean(VectExamExo2);

E3moy=mean(VectExamExo3);

Vectinit=zeros(1,length(indice));
cmpt=0;
for i=1:1:length(indice)
    Vectinit(i)=(VectExamExo1(i)-E1moy)^2+cmpt;
end 
SigE1=sqrt(mean(Vectinit));
fprintf('La moyenne, la m�diane et l Ecart type pour la question de Exercice 1 valent (respectivement): \n %f \n %f \n %f \n',E1moy,median(VectExamExo1),SigE1);

Vectinit=zeros(1,length(indice));
cmpt=0;
for i=1:1:length(indice)
    Vectinit(i)=(VectExamExo2(i)-E2moy)^2+cmpt;
end 
SigE2=sqrt(mean(Vectinit));
fprintf('La moyenne, la m�diane et l Ecart type pour la question de Exercice 2 valent (respectivement): \n %f \n %f \n %f \n',E2moy,median(VectExamExo2),SigE2);

Vectinit=zeros(1,length(indice));
cmpt=0;
for i=1:1:length(indice)
    Vectinit(i)=(VectExamExo3(i)-E3moy)^2+cmpt;
end 
SigE3=sqrt(mean(Vectinit));
fprintf('La moyenne, la m�diane et l Ecart type pour la question de Exercice 3 valent (respectivement): \n %f \n %f \n %f \n',E3moy,median(VectExamExo3),SigE3);
