clear all;
close all;

Exam = xlsread('Proba1ereSess20122013.xls');
%% Question 2b iv et v
% calcul du polygone des fr�quence cumul� pour chaque exercices
n=148;
cmpt1=0;
cmpt2=0;
cmpt3=0;
PropEtudExo=0;
for i=1:1:20;
    PolyFrqCumExo1(i)=length( find(i-1<=Exam(:,8) & Exam(:,8)<i))/n+cmpt1;
    cmpt1=PolyFrqCumExo1(i);
    PolyFrqCumExo2(i)=length( find(i-1<=Exam(:,9) & Exam(:,9)<i))/n+cmpt2;
    cmpt2=PolyFrqCumExo2(i);
    PolyFrqCumExo3(i)=length( find(i-1<=Exam(:,10) & Exam(:,10)<i))/n+cmpt3;
    cmpt3=PolyFrqCumExo3(i);
end





for j=1:100
composante=1:1:length(Exam); % vecteur qui contient les lignes du tableau Exam
indice=randsample(composante,20,true);% Prend al�atoirement les indices du tableau

% Mettre les valeurs pour chaque Exam
for i=1:length(indice)
    VectExamExo1(i)=Exam(indice(i),8);
    VectExamExo2(i)=Exam(indice(i),9);
    VectExamExo3(i)=Exam(indice(i),10);
end

x=1:20;
VectFrqExo1=hist(VectExamExo1,x);
VectFrqExo2=hist(VectExamExo2,x);
VectFrqExo3=hist(VectExamExo3,x);

 n=20;
cmpt1=0;
cmpt2=0;
cmpt3=0;
PropEtudExo=0;
for i=1:1:20;
    PolyFrqCumExo1iid(i)=length( find(i-1<=VectExamExo1 & VectExamExo1<i))/n+cmpt1;
    cmpt1=PolyFrqCumExo1(i);
    PolyFrqCumExo2iid(i)=length( find(i-1<=VectExamExo2 & VectExamExo2<i))/n+cmpt2;
    cmpt2=PolyFrqCumExo2(i);
    PolyFrqCumExo3iid(i)=length( find(i-1<=VectExamExo3 & VectExamExo3<i))/n+cmpt3;
    cmpt3=PolyFrqCumExo3(i);
end

DistKolSmirExo1(j)=max(PolyFrqCumExo1iid-PolyFrqCumExo1);

DistKolSmirExo2(j)=max(PolyFrqCumExo2iid-PolyFrqCumExo2);


DistKolSmirExo3(j)=max(PolyFrqCumExo3iid-PolyFrqCumExo3);


end


hist(DistKolSmirExo1)
title(' Distance de Kolomogorov pour l exercice 1 pour 100 essai d un tirage de 20 �tudiant parmi la population');
figure
hist(DistKolSmirExo2)
title(' Distance de Kolomogorov pour l exercice 2 pour 100 essai d un tirage de 20 �tudiant parmi la population');
figure
hist(DistKolSmirExo3)
title(' Distance de Kolomogorov pour l exercice 3 pour 100 essai d un tirage de 20 �tudiant parmi la population');