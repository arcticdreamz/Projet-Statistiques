clear all;
close all;


Exam = xlsread('Proba1ereSess20122013.xls');
%% QUESTION 1

%% 1.a) Histogrammes
figure
hist(Exam(:,5))
title('Th�orie 1');
xlabel('note obtenu sur 20');
ylabel('nombre d�l�ve ayant obtenu la note indiqu�');
figure
hist(Exam(:,6))
title('Th�orie 2');
xlabel('note obtenu sur 20');
ylabel('nombre d�l�ve ayant obtenu la note indiqu�');
figure
hist(Exam(:,7))
title('Th�orie 3');
xlabel('note obtenu sur 20');
ylabel('nombre d�l�ve ayant obtenu la note indiqu�');