
clear all;
close all;


%% question 2.a.ii)
Q2ai;
Exam = xlsread('Proba1ereSess20122013.xls');

% Mettre les valeurs pour chaque Exam
for i=1:length(indice)
    VectQProjet1(i)=Exam(indice(i),1);
    VectQProjet2(i)=Exam(indice(i),2);
    VectQProjet3(i)=Exam(indice(i),3);
    VectExamQProjet3(i)=Exam(indice(i),4);
end
% 4 boite � moustaches.


boxplot(VectQProjet1)
title('Boite � moustache Projet 1');
figure

boxplot(VectQProjet2)
title('Boite � moustache Projet 2');
figure

boxplot(VectQProjet3)
title('Boite � moustache Projet 3');
figure


boxplot(VectExamQProjet3)
title('Boite � moustache question projet 3');
figure
