function Q2B

resultats=xlsread('Proba1ereSession20132014.xls'); %r�cup�ration des donn�es Excel
matrice_echantillon=zeros(20,100); %Matrice 200 lignes/100 colonnes pour stocker les �chantillons

for i=1:100
    
    echantillon = randsample(120,20,true); %Cr�ation d'un �chantillon de 20 �tudiants 
    matrice_echantillon(:,i)=echantillon; %Remplissage de la matrice contenant les 100 �chantillons, une colonne = un �chantillon

end

%Calcul des moyennes (et nouvelle variable)

points_exercice1=zeros(20,100);
points_exercice2=zeros(20,100);
points_exercice3=zeros(20,100);

for j=1:100
    
    for k=1:20
        
        points_exercice1(k,j) = resultats(matrice_echantillon(k,j),7);
        points_exercice2(k,j) = resultats(matrice_echantillon(k,j),8);
        points_exercice3(k,j) = resultats(matrice_echantillon(k,j),9);
    
    end
    
    moyenne_exercice1(j)=mean(points_exercice1(:,j));
    mediane_exercice1(j)=median(points_exercice1(:,j));
    ecart_type_exercice1(j)=std(points_exercice1(:,j));
    
    
end

%Histogramme de la variable moyenne

moyennes=0:20; %vecteur abscisse

hist(moyenne_exercice1,moyennes); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]); % commande pour afficher toutes les graduations
xlabel('Moyennes de l exercice 1 pour les 100 �chantillons');
ylabel('Fr�quences des moyennes');
title('Histogramme des moyennes de l exercice 1 pour les 100 �chantillons');

%Moyenne de la moyenne

moyenne_moyenne=mean(moyenne_exercice1)

%Histogramme de la variable mediane 

medianes=0:20; %vecteur abscisse

figure
hist(mediane_exercice1,medianes); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]); % commande pour afficher toutes les graduations
xlabel('M�dianes de l exercice 1 pour les 100 �chantillons');
ylabel('Fr�quences des m�dianes');
title('Histogramme des m�dianes de l exercice 1 pour les 100 �chantillons');

%Moyenne de la m�diane 

moyenne_mediane=mean(mediane_exercice1)

%Histogramme de la variable �cart-type 

ecart_type=0:20; %vecteur abscisse

figure
hist(ecart_type_exercice1,ecart_type); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]); % commande pour afficher toutes les graduations
xlabel('Ecart-type de l exercice 1 pour les 100 �chantillons');
ylabel('Fr�quences des �cart-types');
title('Histogramme des �cart-types de l exercice 1 pour les 100 �chantillons');

%Moyenne de l'�cart-type 

moyenne_ecart_type=mean(ecart_type_exercice1)

%Distance Kolmogorov-Smirnov pour l'exercice 1

for m=1:100

[~, ~, dks]=kstest2(resultats(:,7), points_exercice1(:,m));
distance_ks(m)=dks;
 
end

%Histogramme distance Kolmogorov-Smirnov (ex1)

distances=0:0.1:1; %vecteur abscisse

figure
hist(distance_ks,distances); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 .1 .2 .3 .4 .5 .6 .7 .8 .9 1]); % commande pour afficher toutes les graduations
xlabel('Distances de KS');
ylabel('Fr�quences des distances');
title('Histogramme des distances de Kolmogorov Smirnov (ex1)');

%Distance Kolmogorov-Smirnov pour l'exercice 2

for m=1:100

[~, ~, dks2]=kstest2(resultats(:,8), points_exercice2(:,m));
distance_ks2(m)=dks2;
 
end

%Histogramme distance Kolmogorov-Smirnov (ex2)

distances=0:0.1:1; %vecteur abscisse

figure
hist(distance_ks2,distances); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 .1 .2 .3 .4 .5 .6 .7 .8 .9 1]); % commande pour afficher toutes les graduations
xlabel('Distances de KS');
ylabel('Fr�quences des distances');
title('Histogramme des distances de Kolmogorov Smirnov (ex2)');

%Distance Kolmogorov-Smirnov pour l'exercice 3

for m=1:100

[~, ~, dks3]=kstest2(resultats(:,9), points_exercice3(:,m));
distance_ks3(m)=dks3;
 
end

%Histogramme distance Kolmogorov-Smirnov (ex2)

distances=0:0.1:1; %vecteur abscisse

figure
hist(distance_ks3,distances); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 .1 .2 .3 .4 .5 .6 .7 .8 .9 1]); % commande pour afficher toutes les graduations
xlabel('Distances de KS');
ylabel('Fr�quences des distances');
title('Histogramme des distances de Kolmogorov Smirnov (ex3)');
end

