function Q1E

resultats=xlsread('Proba1ereSession20132014.xls'); %r�cup�ration des donn�es Excel

scatter(resultats(:,2),resultats(:,3)); % Scatter dessine le graphe de dispersion comparant les r�sultats du projet 2 � ceux de la question sur le projet 2
xlabel('R�sultats du projet 2');
ylabel('R�sultats de la question sur le projet 2');
title('Graphe de dipersion comparant les r�sultats du projet 2 et ceux de la question sur le projet 2');

%Coefficient de corr�lation 

cc=corrcoef(resultats(:,2),resultats(:,3));
coefficient_correlation=cc(1,2)
end

