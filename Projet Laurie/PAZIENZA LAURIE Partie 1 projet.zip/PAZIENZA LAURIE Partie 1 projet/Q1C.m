function Q1C

resultats=xlsread('Proba1ereSession20132014.xls'); %r�cup�ration des donn�es Excel

boxplot(resultats(:,1)); %cr�e et affiche le boxplot
title('Boxplot des r�sultats du projet 1');

figure
boxplot(resultats(:,2));
title('Boxplot des r�sultats du projet 2');

figure
boxplot(resultats(:,3));
title('Boxplot des r�sultats de la question-projet');

%Calcul des quartiles : 

quartiles_projet1 = quantile(resultats(:,1), [.25 .50 .75]) %la fonction quantile calcule les quartiles pour 25%, 50%, 75%
quartiles_projet2 = quantile(resultats(:,2), [.25 .50 .75])
quartiles_qprojet = quantile(resultats(:,3), [.25 .50 .75])
end
   