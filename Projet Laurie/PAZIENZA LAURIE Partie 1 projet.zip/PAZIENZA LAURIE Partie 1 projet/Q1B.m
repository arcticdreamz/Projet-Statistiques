function Q1B
resultats=xlsread('Proba1ereSession20132014.xls');%r�cup�ration des donn�es Excel

exercice1=resultats(:,7); %Stockage des r�sultats de l'exercice 1
exercice2=resultats(:,8); %Stockage des r�sultats de l'exercice 2
exercice3=resultats(:,9); %Stockage des r�sultats de l'exercice 3

%Calcul des moyennes : 

moyenne_exercice1=mean(exercice1) %la fonction mean calcule la moyenne d'un vecteur
moyenne_exercice2=mean(exercice2)
moyenne_exercice3=mean(exercice3)


%Calcul des m�dianes : 

mediane_exercice1=median(exercice1) %la fonction median calcule la m�diane d'un vecteur
mediane_exercice2=median(exercice2)
mediane_exercice3=median(exercice3)

%Calcul des modes :

mode_exercice1=mode(exercice1) %%la fonction mode calcule la m�diane d'un vecteur
mode_exercice2=mode(exercice2)
mode_exercice3=mode(exercice3)

%Calcul des �carts types : 

ecart_type_exercice1=std(exercice1) %la fonction std calcule l'�cart-type d'un vecteur
ecart_type_exercice2=std(exercice2)
ecart_type_exercice3=std(exercice3)

%R�sultats normaux : 

min_exercice1 = moyenne_exercice1-ecart_type_exercice1; %bornes de l'intervalle 
min_exercice2 = moyenne_exercice2-ecart_type_exercice2;
min_exercice3 = moyenne_exercice3-ecart_type_exercice3;
max_exercice1 = moyenne_exercice1+ecart_type_exercice1;
max_exercice2 = moyenne_exercice2+ecart_type_exercice2;
max_exercice3 = moyenne_exercice3+ecart_type_exercice3;

elevesnormaux_exercice1=0;
elevesnormaux_exercice2=0;
elevesnormaux_exercice3=0;

nombre_etudiants=max(size(resultats));

for i=1:nombre_etudiants
   
    if exercice1(i)>=min_exercice1 && exercice1(i)<=max_exercice1
        elevesnormaux_exercice1=elevesnormaux_exercice1 + 1;
    end    
     
    if exercice2(i)>=min_exercice2 && exercice2(i)<=max_exercice2
        elevesnormaux_exercice2=elevesnormaux_exercice2 + 1;
    end    
     
    if exercice3(i)>=min_exercice3 && exercice3(i)<=max_exercice3
        elevesnormaux_exercice3=elevesnormaux_exercice3 + 1;
    end
    
end

elevesnormaux_exercice1/1.2
elevesnormaux_exercice2/1.2
elevesnormaux_exercice3/1.2
end

