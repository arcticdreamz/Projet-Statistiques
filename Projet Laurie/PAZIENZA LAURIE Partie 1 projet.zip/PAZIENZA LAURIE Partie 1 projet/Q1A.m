function Q1A
resultats=xlsread('Proba1ereSession20132014.xls'); %r�cup�ration des donn�es Excel
points=0:22; %vecteur abscisse

hist(resultats(:,4),points); %fonction hist trace l'histogramme des donn�es
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]); % commande pour afficher toutes les graduations
xlabel('Points');
ylabel('Nombre d �tudiants');
title('Histogramme de la Q1 de th�orie');

figure
hist(resultats(:,5),points);
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22]); % commande pour afficher toutes les graduations
xlabel('Points');
ylabel('Nombre d �tudiants');
title('Histogramme de la Q2 de th�orie');

figure
hist(resultats(:,6),points);
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21]); % commande pour afficher toutes les graduations
xlabel('Points');
ylabel('Nombre d �tudiants');
title('Histogramme de la Q3 de th�orie');

end

