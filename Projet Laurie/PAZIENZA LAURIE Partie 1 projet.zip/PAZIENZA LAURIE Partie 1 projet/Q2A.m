function Q2A

resultats=xlsread('Proba1ereSession20132014.xls'); %r�cup�ration des donn�es Excel

echantillon = randsample(120,20,true); %Cr�ation d'un �chantillon de 20 �tudiants 

for i=1:20
    
    exercice1(i)=resultats(echantillon(i),7); %r�cup�ration des r�sulats des exercices de ces 20 �tudiants
    exercice2(i)=resultats(echantillon(i),8);
    exercice3(i)=resultats(echantillon(i),9);
    projet1(i)=resultats(echantillon(i),1);
    projet2(i)=resultats(echantillon(i),2);
    qprojet2(i)=resultats(echantillon(i),3);
    theorie1(i)=resultats(echantillon(i),4); 
    theorie2(i)=resultats(echantillon(i),5);
    theorie3(i)=resultats(echantillon(i),6);
    
end

%Calcul des moyennes :

moyenne_exercice1=mean(exercice1)
moyenne_exercice2=mean(exercice2)
moyenne_exercice3=mean(exercice3)
    
%Calcul des m�dianes :

mediane_exercice1=median(exercice1)
mediane_exercice2=median(exercice2)
mediane_exercice3=median(exercice3)
    
%Calcul des �cart-types:

ecart_type_exercice1=std(exercice1)
ecart_type_exercice2=std(exercice2)
ecart_type_exercice3=std(exercice3)

%Boxplot

boxplot(projet1); %cr�e et affiche le boxplot
title('Boxplot des r�sultats du projet 1 de l �chantillon');

figure
boxplot(projet2);
title('Boxplot des r�sultats du projet 2 de l �chantillon');

figure
boxplot(qprojet2);
title('Boxplot des r�sultats de la question-projet de l �chantillon');

%Moyenne de chaque �tudiant de l'�chantillon pour la th�orie

moyenne_theorie=(theorie1(:)+theorie2(:)+theorie3(:))/3;

%Polygone des fr�quences cumul�es 
moyenne_theoriepopu=Q1D;

cdfplot(moyenne_theorie);
xlabel('Points');
ylabel('Fr�quences cumul�es');
title('Polygone des fr�quences cumul�es pour la th�orie de l �chantillon');

figure
cdfplot(moyenne_theorie);
hold on 
h=cdfplot(moyenne_theoriepopu);
set(h,'color','r')
xlabel('Points');
ylabel('Fr�quences cumul�es');
title('Polygones des fr�quences cumul�es pour la th�orie de l �chantillon et pour la population');

%Distance de Kolmogorov Smirnov


[~, ~, distance_ks]=kstest2(moyenne_theoriepopu, moyenne_theorie);
distance_ks
end

