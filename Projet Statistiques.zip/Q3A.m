function [mean_biais, mean_var] = Q3A()
data = xlsread('Database.xlsx');

% Matrice des echantillons
echantillons = zeros(20,100); 
% Matrice des moyennes de chaque echantillon
wine_mean_matrix = zeros(100,1);

% Creation des echantillons
for j = 1:100
    index_echantillon = randsample(100,20,true);
    for i = 1:20
        echantillons(i,j) = data(index_echantillon(i),3); % On reprend seulement la consommation de vin
    end
    % Calcul des moyennes de chaque echantillon
    wine_mean_matrix(j) = mean(echantillons(:,j));
end

% Calcul du biais
real_wine_mean = mean(data(:,3));
mean_biais = mean(wine_mean_matrix) - real_wine_mean;

% Calcul de la variance
mean_var = var(wine_mean_matrix,1);

end

