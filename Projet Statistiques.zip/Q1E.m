function F = Q1E()
data = xlsread('Database.xlsx');

% Affichage du polygone des frequences cumulees
cdfplot(data(:,1));
xlabel('Nombre de canettes consommees');
ylabel('Frequences cumulees');
title('\fontsize{10}Polygone des frequences cumulees de la consommation de biere');

% Verification de la proportion de pays ayant une consommation comprise entre [200, 295]
[F, x] = cdfcalc(data(:,1));
F_a = F(find(x >= 200, 1 ));
F_b = F(find(x > 295, 1 ));

F = F_b - F_a;

end

