function Q1A()
data = xlsread('Database.xlsx');

% Histogramme de la consommation de biere
histogram(data(:,2),0:25:400);
xlabel('Nombre de canettes consommees');
ylabel('Nombres de pays concernes');
title('Histogramme de la consommation de biere dans le monde');

% Histogramme de la consommation d'alcool fort
figure
histogram(data(:,3),0:25:450);
axis([0 450 0 80]);
xlabel('Nombre de shots consommes');
ylabel('Nombres de pays concernes');
title('Histogramme de la consommation d alcool fort dans le monde');

end


