function [quartile_beer, quartile_spirit] = Q1D()
data = xlsread('Database.xlsx');

% Affichage des boites a moustaches
boxplot(data(:,1));
ylabel('Nombres de verres consommes');
title('Boite a moustache de la consommation de biere');

figure
boxplot(data(:,2));
ylabel('Nombres de shots consommes');
title('Boite a moustache de la consommations d alcool fort');

% Calcul des quartiles
quartile_beer = quantile(data(:,1), [0.25 0.50 0.75]);
quartile_spirit = quantile(data(:,2), [0.25 0.50 0.75]);

end

