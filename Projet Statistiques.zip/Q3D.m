function [counter_student, counter_gauss] = Q3D()
data = xlsread('Database.xlsx');

% Matrice des echantillons
echantillons = zeros(20,100); 
% Matrice des moyennes de chaque echantillon
wine_mean_matrix = zeros(100,1);

% Creation des echantillons
for j = 1:100
    index_echantillon = randsample(100,20,true);
    for i = 1:20
        echantillons(i,j) = data(index_echantillon(i),3); % On reprend seulement la consommation de vin
    end
    % Calcul des moyennes de chaque echantillon
    wine_mean_matrix(j) = mean(echantillons(:,j));
end

% Donnees
n = 20;
alpha = 0.05;
real_wine_mean = mean(data(:,3));

% Initialisation des variables
s_tmp = zeros(100,1);
s_student = zeros(100,1);
s_gauss = zeros(100,1);
min_student = zeros(100,1);
max_student = zeros(100,1);
min_gauss = zeros(100,1);
max_gauss = zeros(100,1);
counter_student = 0;
counter_gauss = 0;

% i) Intervalle construit avec la loi de Student
t = tinv(1-alpha/2, n-1);

for j=1:100
    for i=1:20
        s_tmp(j) = s_tmp(j) + (echantillons(i,j) - wine_mean_matrix(j))^2;
    end
    % Calcul des S_n
    s_student(j) = sqrt(s_tmp(j)/(n-1)); 
end

for j=1:100
    % Calcul des bornes des intervalles
    min_student(j) = wine_mean_matrix(j) - (t*s_student(j)/sqrt(n));
    max_student(j) = wine_mean_matrix(j) + (t*s_student(j)/sqrt(n));
    
    if real_wine_mean >= min_student(j) && real_wine_mean <= max_student(j)
        counter_student = counter_student + 1;
    end
end


% ii) Intervalle construit avec la loi de Gauss
u = norminv(1-alpha/2, 0, 1);

for j=1:100
    for i=1:20
       % Calcul de l'ecart-type
       s_gauss(j) = sqrt(var(echantillons(:,j),1));
    end 
end

for j=1:100
    % Calcul des bornes des intervalles
    min_gauss(j) = wine_mean_matrix(j) - (u*s_gauss(j)/sqrt(n));
    max_gauss(j) = wine_mean_matrix(j) + (u*s_gauss(j)/sqrt(n));
    
    if real_wine_mean >= min_gauss(j) && real_wine_mean <= max_gauss(j)
        counter_gauss = counter_gauss + 1;
    end
end

end

