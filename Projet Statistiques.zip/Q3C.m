function [mean_biais,mean_var,median_biais,median_var] = Q3C()
data = xlsread('Database.xlsx');

% Matrice des echantillons
echantillons = zeros(50,100); 
% Matrice des moyennes de chaque echantillon
wine_mean_matrix = zeros(100,1);
% Matrice des medianes de chaque echantillon
wine_median_matrix = zeros(100,1);

% Creation des echantillons
for j = 1:100
    index_echantillon = randsample(100,50,true);
    for i = 1:50
        echantillons(i,j) = data(index_echantillon(i),3); % On reprend seulement la consommation de vin
    end
    % Calcul des moyennes de chaque echantillon
    wine_mean_matrix(j) = mean(echantillons(:,j));
    % Calcul des medianes de chaque echantillon
    wine_median_matrix(j) = median(echantillons(:,j));
end

% Calcul des biais
real_wine_mean = mean(data(:,3));
mean_biais = mean(wine_mean_matrix) - real_wine_mean;
median_biais = mean(wine_median_matrix) - real_wine_mean;

% Calcul des variances
mean_var = var(wine_mean_matrix,1);
median_var = var(wine_median_matrix,1);

end

