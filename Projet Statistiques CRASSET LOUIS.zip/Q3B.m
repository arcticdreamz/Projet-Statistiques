function [median_biais, median_var] = Q3B()
data = xlsread('Database.xlsx');

% Matrice des echantillons
echantillons = zeros(20,100); 
% Matrice des medianes de chaque echantillon
wine_median_matrix = zeros(100,1);

% Creation des echantillons
for j = 1:100
    index_echantillon = randsample(100,20,false);
    for i = 1:20
        echantillons(i,j) = data(index_echantillon(i),3); % On reprend seulement la consommation de vin
    end
    % Calcul des medianes de chaque echantillon
    wine_median_matrix(j) = median(echantillons(:,j));
end

% Calcul du biais
real_wine_mean = mean(data(:,3));
median_biais = mean(wine_median_matrix) - real_wine_mean;

% Calcul de la variance
median_var = var(wine_median_matrix,1);

end

