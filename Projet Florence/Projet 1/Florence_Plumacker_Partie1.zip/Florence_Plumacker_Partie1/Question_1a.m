function Question_1a(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);
subplot (221);
LOL1 = hist(Resultats_Etudiants(:,4), 21);%R�sultats de la premi�re question de th�orie
bar(LOL1)
ylabel('Nombre d �tudiants')
xlabel('Cote sur 20')
title('Histogramme de la premi�re question de th�orie')
subplot (222);
LOL = hist(Resultats_Etudiants(:,5), 21);%R�sultats de la deuxi�me question de th�orie
bar(LOL)
ylabel('Nombre d �tudiants')
xlabel('Cote sur 20')
title('Histogramme de la deuxi�me question de th�orie')
subplot(223);
LOL3  = hist(Resultats_Etudiants(:,6), 21);%R�sultats de la troisi�me question de th�orie
bar(LOL3)
ylabel('Nombre d �tudiants')
xlabel('Cote sur 20')
title('Histogramme de la troisi�me question de th�orie')
