function Question_1e(NomDuFichier)


Resultats_Etudiants = xlsread(NomDuFichier);
scatter(Resultats_Etudiants(:,2), Resultats_Etudiants(:,3));
corrcoef(Resultats_Etudiants(:,2), Resultats_Etudiants(:,3));
end
