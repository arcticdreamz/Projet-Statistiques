function C = Question_2b(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);



FreqcumPOPEx1 = cdfcalc(Resultats_Etudiants(:,7));
FreqcumPOPEx2 = cdfcalc(Resultats_Etudiants(:,8));
FreqcumPOPEx3 = cdfcalc(Resultats_Etudiants(:,9));

%%G�n�ration des vecteurs al�atoires.
for i = 1:100
Vecteur_Aleatoirei = randsample (120, 20, true);
EchantillonEx1 = Resultats_Etudiants(Vecteur_Aleatoirei, 7);
EchantillonEx2 =Resultats_Etudiants(Vecteur_Aleatoirei, 8);
EchantillonEx3 =Resultats_Etudiants(Vecteur_Aleatoirei, 9);

MoyenneEx1(i) = mean(EchantillonEx1);%Moyenne pour chaque �chantillon
MedianEx1(i) = median(EchantillonEx1);%M�diane pour chaque �chantillon
EcartEx1(i) = std(EchantillonEx1,1);%Ecart-type pour chaque �chantillon


FreqcumEchEx1 = cdfcalc(EchantillonEx1) ;
FreqcumEchEx2 = cdfcalc(EchantillonEx2) ;
FreqcumEchEx3 = cdfcalc(EchantillonEx3) ;
[~,~, DistKolmoEx1(i)] = kstest2(FreqcumEchEx1, FreqcumPOPEx1);%Distance de Kolmogorov pour chaque �chantillon pour l'ex1

[~,~,DistKolmoEx2(i)] = kstest2(FreqcumEchEx2, FreqcumPOPEx2);%Distance de Kolmogorov pour chaque �chantillon pour l'ex1

[~,~,DistKolmoEx3(i)] = kstest2(FreqcumEchEx3, FreqcumPOPEx3);%Distance de Kolmogorov pour chaque �chantillon pour l'ex1
end

%Affichage des histogrammes
figure
hist(MoyenneEx1,21);

title('Histogramme des moyennes des r�sultats de l exercice 1 pour les 100 �chantillons.')
xlabel('Cote sur 20')
ylabel('Nombre d �chantillons')
figure
hist(MedianEx1,21);

title('Histogramme des m�dianes des r�sultats de l exercice 1 pour les 100 �chantillons.')
xlabel('Cote sur 20')
ylabel('Nombre d �chantillons')
figure
hist(EcartEx1,21);
title('Histogramme des �carts types r�sultats de l exercice 1 pour les 100 �chantillons.')
xlabel('Ecart-type')
ylabel('Nombre d �chantillons')

%Calcul des moyennes
MoyenMoyenne = mean(MoyenneEx1)
MoyennePopu= mean(Resultats_Etudiants(:,7))
MoyenMedian = mean(MedianEx1)
MedianPopu = median(Resultats_Etudiants(:,7))
MoyenEcart = mean(EcartEx1)
EcarPopu = std(Resultats_Etudiants(:,7),1)

%affichage des distances de Kolmogorov
figure
hist(DistKolmoEx1, 21)
title('Histogramme des distances de Kolmogrorov pour l exercice 1')
ylabel('Nombre d �chantillons')
xlabel('Distance de Kolomogorov')
figure
hist(DistKolmoEx2, 21)
title('Histogramme des distances de Kolmogrorov pour l exercice 2')
ylabel('Nombre d �chantillons')
xlabel('Distance de Kolomogorov')
figure
hist(DistKolmoEx3, 21)
title('Histogramme des distances de Kolmogrorov pour l exercice 3')
ylabel('Nombre d �chantillons')
xlabel('Distance de Kolomogorov')
end
