function C = Question_2a(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);
A = size(Resultats_Etudiants);

%%G�n�ration du vecteur al�atoire.
Vecteur_Aleatoire = randsample (A(1), 20, true);
Echantillon = Resultats_Etudiants(Vecteur_Aleatoire,:);

%%Calcul des moyennes, m�diannes, �cart-types
C(:,1) = mean(Echantillon(:, 7:9));
C(:,2) = median(Echantillon(:, 7:9));
C(:,3) = std(Echantillon(:, 7:9),1);

%%Affichage des boites � Moustache
subplot(131) ;
boxplot(Echantillon(:,1));
title('Projet 1');
subplot(132);
boxplot(Echantillon(:,2));
title('Projet 2');
subplot(133);
boxplot(Echantillon(:,3));
title('Question sur le projet');

%%Polygones des fr�quences cumul�es
for i = 1:20
MoyenEchTheo(i) = mean(Echantillon(i,4:6));
end


figure
FreqcumEchT = cdfcalc(MoyenEchTheo);

cdfplot(MoyenEchTheo)
title('Polygone des fr�quences cumul�es des r�sultats de la th�orie pour un �chantillon')

xlabel('Cote sur 20')
ylabel('Fr�quences cumul�es') 



%Distance de Kolmogorov-Smirnov

FreqCumPop =  Question_1d(NomDuFichier);
[~,~, Kolmo] = kstest2(FreqcumEchT, FreqCumPop);
DistKolmo = max(Kolmo)
end

