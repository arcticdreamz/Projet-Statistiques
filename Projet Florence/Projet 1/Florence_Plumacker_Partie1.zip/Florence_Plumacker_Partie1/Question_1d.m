function FreqCum =  Question_1d(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);

%Calcul des moyennes
for i = 1:120
MoyenTheo(i) = mean(Resultats_Etudiants(i,4:6));
MoyenExo(i) = mean(Resultats_Etudiants(i,7:9));
end


%Affichage des polygones
subplot(121)
cdfplot(MoyenTheo)
title('Polygone des fr�quences cumul�es pour la th�orie')
xlabel('Cote sur 20')
ylabel('Fr�quences cumul�es') 
subplot(122)
cdfplot(MoyenExo)
title('Polygone des fr�quences cumul�es pour les excercices')
xlabel('Cote sur 20')
ylabel('Fr�quences cumul�es') 
FreqCum = cdfcalc(MoyenTheo);
end