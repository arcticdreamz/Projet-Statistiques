function C =  Question_1b(NomDuFichier)


Resultats_Etudiants = xlsread(NomDuFichier);
C(:,1) = mean(Resultats_Etudiants(:, 7:9));
C(:,2) = median(Resultats_Etudiants(:, 7:9));
C(:,3) = mode(Resultats_Etudiants(:, 7:9));
C(:,4) = std(Resultats_Etudiants(:, 7:9),1));

%Calcul de l'intervalle normal

Interv(:,2) = C(:,1)+C(:,4)
Interv(:,1) = C(:,1) - C(:,4)

%Calcul du pourcentage compris dans cet intervalle
S = size(Resultats_Etudiants);
for j = 7:9
    Count(j-6) = 0;
    
for i=1:S(1)
    if Interv(j-6,1)<= Resultats_Etudiants(i,j) &&  Resultats_Etudiants(i,j)<=Interv(j-6,2)
        Count (j-6) = Count(j-6) + 1;
    end
end
Norm(j-6) = Count(j-6)/120;
end
Norm






