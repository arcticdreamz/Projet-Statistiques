function Question_1c(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);
S = size(Resultats_Etudiants);
n=50;
%Calcul des moyennes des �tudiants
for i = 1:S(1)
Resultat_Final(i) = mean(Resultats_Etudiants(i, 1:S(2)));
end
%Cr�ation des �chantillons de taille 50
for j = 1:100
    Vecteurs_Aleatoires(:,j) = randsample(S(1), n);
end

%Calcul de la variable des moyennes
for j=1:100
Moyenne_Echantillons(j) = mean(Resultat_Final(Vecteurs_Aleatoires(:,j)));
end
%Calcul du biais et de la variance
Moyenne_Totale = mean(Resultat_Final);
Biais_a = mean(Moyenne_Echantillons) - Moyenne_Totale
Variance_a = var(Moyenne_Echantillons, 1)

%Calcul de la variable des m�dianes
for j = 1:100
    MedianeX(j) =median(Resultat_Final(Vecteurs_Aleatoires(:,j))); 
end

%Calcul du biais et de la variance
Mediane_Totale = median(Resultat_Final);
Biais_b = mean(MedianeX) - Mediane_Totale
Variance_b = var(MedianeX, 1)
end