function Question_1d(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);
S = size(Resultats_Etudiants);
n=20;
s_n1Carr = zeros(1,100);
Cpt = 0;
Cpt2 = 0;

%Calcul des moyennes des �tudiants 
for i = 1:S(1)
Resultat_Final(i) = mean(Resultats_Etudiants(i, 1:S(2)));
end
Moyenne_Totale = mean(Resultat_Final);

%Cr�ation des �chantillons de taille 20
for j = 1:100
    Vecteurs_Aleatoires(:,j) = randsample(S(1), n);
end

%Calcul de la variable des moyennes et de s_(n-1)
for j=1:100
Moyenne_Echantillons(j) = mean(Resultat_Final(Vecteurs_Aleatoires(:,j)));
for i = 1:n
s_n1Carr(j) = s_n1Carr(j) + (Resultat_Final(Vecteurs_Aleatoires(i,j))-Moyenne_Echantillons(j))^2;
end
s_n1(j) = sqrt(s_n1Carr(j)/(n-1));
s_n(j) = sqrt(var(Resultat_Final(Vecteurs_Aleatoires(:,j)),1));
end


%Calcul de l'intervalle selon Student
t = 2.093;
u = 1.96;
for j=1:100
Borne1_Student(j) = Moyenne_Echantillons(j) - t*s_n1(j) /sqrt(n);
Borne2_Student(j) = Moyenne_Echantillons(j) + t*s_n1(j) /sqrt(n);
Borne1_Gauss(j) = Moyenne_Echantillons(j) - u*s_n(j)/sqrt(n);
Borne2_Gauss(j) = Moyenne_Echantillons(j) + u*s_n(j)/sqrt(n);

if Moyenne_Totale<Borne2_Student(j) && Moyenne_Totale>Borne1_Student(j)
    Cpt = Cpt +1;
end
if Moyenne_Totale<Borne2_Gauss(j) && Moyenne_Totale>Borne1_Gauss(j)
    Cpt2 = Cpt2 +1;
end
end
Cpt
Cpt2
end







