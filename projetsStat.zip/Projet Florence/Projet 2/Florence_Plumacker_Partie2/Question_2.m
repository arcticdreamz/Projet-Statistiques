function Question_2(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);
S = size(Resultats_Etudiants);
n=20;
u = 1.645;

nOrg =7;
%Calcul des moyennes des �tudiants
for i = 1:S(1)
Resultat_Final(i) = mean(Resultats_Etudiants(i, 1:S(2)));
end
%Cr�ation de 7 �chantillons de taille 20
for j=1:nOrg
    CPT(j) = 0;
    p(j,1:100) = 0;
    for t=1:100
        Vecteurs_Aleatoires(:,j,t) = randsample(S(1), n);
        for i=1:n
            if Resultat_Final(Vecteurs_Aleatoires(i,j,t))<=10
                p(j,t) = p(j,t)+1;

            end

        end
     p(j,t) = p(j,t)/20;

    end
end

%Rejet de l'Ulg
for t = 1:100
        if p(1,t)>(1/8+ u *sqrt(1/8*(1-1/8)/20))
            CPT(1) = CPT(1)+1;
        end
end
%Publication de l'article
A = 0; %Nombre de non publications
    for t=1:100
        

        if p(2,t) <=(1/8+ u * sqrt(1/8*(1-1/8)/20))
            if p(3,t) <=(1/8+ u * sqrt(1/8*(1-1/8)/20))
                if p(4,t) <=(1/8 + u * sqrt(1/8*(1-1/8)/20))
                    if p(5,t) <=(1/8+ u * sqrt(1/8*(1-1/8)/20))
                        if p(6,t) <=(1/8+ u * sqrt(1/8*(1-1/8)/20))
                            if p(7,t) <=(1/8+ u * sqrt(1/8*(1-1/8)/20))
                                %Tous les organismes ont accept�
                                A = A+1;
                            end
                        end
                    end
                end
            end
        
        end
    end

disp('Nombre de publications')        
100-A     
disp('Nombre de rejets pour l Ulg')
CPT(1)
end
