function Question_1ab(NomDuFichier)
Resultats_Etudiants = xlsread(NomDuFichier);
S = size(Resultats_Etudiants);
n=20;
%moyennes
for i = 1:S(1)
results(i) = mean(Resultats_Etudiants(i, 1:S(2)));
end
%�chantillons
for j = 1:100
    VecAl(:,j) = randsample(S(1), n);
end

%variable des moyennes
for j=1:100
Moyech(j) = mean(results(VecAl(:,j)));
end
%biais et variance
Moytot = mean(results)
Biaisancea = mean(Moyech) - Moytot
Vara = var(Moyech, 1)

%variable des m�dianes
for j = 1:100
    Med(j) =median(results(VecAl(:,j))); 
end

%biais et variance
Biaisanceb = mean(Med) - Moytot
Varb = var(Med, 1)
end


