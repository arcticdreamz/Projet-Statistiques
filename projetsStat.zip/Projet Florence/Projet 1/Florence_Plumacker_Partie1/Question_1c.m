function  Question_1c(NomDuFichier)


Resultats_Etudiants = xlsread(NomDuFichier);

%Affichage des boites � moustache
subplot(131) ;
boxplot(Resultats_Etudiants(:,1));
title('Projet 1');
subplot(132);
boxplot(Resultats_Etudiants(:,2));
title('Projet 2');
subplot(133);
boxplot(Resultats_Etudiants(:,3));
title('Question sur le projet');

%Calcul des quartiles
Quartile2(1) = quantile(Resultats_Etudiants(:,1),0.5);
Quartile2(2) = quantile(Resultats_Etudiants(:,2),0.5);
Quartile2(3) = quantile(Resultats_Etudiants(:,3),0.5);
Quartile1(1) = quantile(Resultats_Etudiants(:,1),0.25);
Quartile1(2) = quantile(Resultats_Etudiants(:,2),0.25);
Quartile1(3) = quantile(Resultats_Etudiants(:,3),0.25);
Quartile3(1) = quantile(Resultats_Etudiants(:,1),0.75);
Quartile3(2) = quantile(Resultats_Etudiants(:,2),0.75);
Quartile3(3) = quantile(Resultats_Etudiants(:,3),0.75);
Quartile1
Quartile2
Quartile3


