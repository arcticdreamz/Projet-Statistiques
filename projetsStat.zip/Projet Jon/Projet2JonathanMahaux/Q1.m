%Reponse a la premiere partie du projet 2 

function Q1

format long
X = xlsread('Proba1ereSession20132014.xls');

[m n] =size(X);

%generation des notes finales

for i=1:1:m 
    notef(i)= mean(X(i,:));
end
%donnees utiles aux calculs

 moy = mean(notef)
 t=2.093;
 mu_alpha = 1.96;
 n_student=0;
 n_gauss = 0;
 
 % tirage des 100 echantillons iid
for i=1:1:100
    
    echantillon1 = randsample(m,20,true);
    echantillon2 = randsample(m,50,true);
    
    
    for k=1:1:20
        valeur_echantillon1(k) = notef(echantillon1(k));
    end
    for k=1:1:50
        valeur_echantillon2(k) = notef(echantillon2(k));
    end
    
%moyenne pour les echantillons de taille 20 et 50
moyech1(i) = mean(valeur_echantillon1);
moyech2(i) = mean(valeur_echantillon2);

%mediane des echantillons
med1(i) = median(valeur_echantillon1);
med2(i) = median(valeur_echantillon2);

%ecart par rapport a la moyenne
ecart1_moy(i) = moyech1(i)-moy;
ecart2_moy(i) = moyech2(i)-moy;

ecart1_med(i)= med1(i)-moy;
ecart2_med(i)= med2(i)-moy;

%estimateurs de l ecart-type
s_student(i) = std(valeur_echantillon1);
s_gauss(i) = std(valeur_echantillon1,1);

%bornes pour la loi de Student
borne_student(i,1) = moyech1(i)-(t*s_student(i)/sqrt(20));
borne_student(i,2) = moyech1(i)+(t*s_student(i)/sqrt(20));

%nombre d acceptation de l hypothese
if moy>= borne_student(i,1) && moy<= borne_student(i,2)
    n_student = n_student+1;
end

%bornes pour la loi de gauss
borne_gauss(i,1) = moyech1(i)-(mu_alpha*s_gauss(i)/sqrt(20));
borne_gauss(i,2)= moyech1(i)+(mu_alpha*s_gauss(i)/sqrt(20));

%nombre d acceptation de l hypothese
if moy>= borne_gauss(i,1) && moy<= borne_gauss(i,2)
    n_gauss = n_gauss+1;
end

end
%calcul du biais
biais1_moy = mean(ecart1_moy)
biais2_moy = mean(ecart2_moy)

biais1_med =mean(ecart1_med)
biais2_med =mean(ecart2_med)

%calcul de la variance
variance1_moy = var(moyech1,1)
variance2_moy = var(moyech2,1)

variance1_med = var(med1,1)
variance2_med = var(med2,1)

n_student
n_gauss

%calcul des bornes par moyennage
b1_student =mean(borne_student(:,1))
b2_student =mean(borne_student(:,2))
b1_gauss =mean(borne_gauss(:,1))
b2_gauss =mean(borne_gauss(:,2))

end