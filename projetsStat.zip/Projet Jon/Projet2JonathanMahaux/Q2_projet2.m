%Script de la question 2

function Q2_projet2

format long
X = xlsread('Proba1ereSession20132014.xls');

[m n] = size(X);
%donnees utiles aux calculs
p1_0 = 0.125
mu_alpha= 1.645;
ecart_type = sqrt(p1_0*(1-p1_0)/20)

%allocation des variables

rejet1 = 0;
rejet2 = 0;
prop =zeros(7,1,100);
cpt = 0;

%generation des notes finales
for i=1:1:m 
    notef(i)= mean(X(i,:));
end

%generation des echantillons
for i=1:1:100
    
    %7 echantillons differents
    for k=1:1:7
        
        echantillon = randsample(m,20,true);
        
        %20 notes par echantillon
    for j=1:1:20
        valeur_echantillon(k,j,i) = notef(echantillon(j));
        
        %proportion en dessous de 10
        if valeur_echantillon(k,j,i) <= 10
            prop(k,1,i) = prop(k,1,i)+1/20 ; 
        end
        
    end
    end
    
    % test pour les autorites par rejet de l hypothese
    if prop(1,1,i)>= p1_0 + mu_alpha*ecart_type
        rejet1 = rejet1+1;
    end
    
    %test pour les instituts par rejet de l hypothese
    if prop(2,1,i)>p1_0 + mu_alpha*ecart_type|| prop(3,1,i)>p1_0 + mu_alpha*ecart_type||prop(4,1,i)>p1_0 + mu_alpha*ecart_type||prop(5,1,i)>p1_0 + mu_alpha*ecart_type||prop(6,1,i)>p1_0 + mu_alpha*ecart_type||prop(7,1,i)>p1_0 + mu_alpha*ecart_type
        incr=1;
    else 
        incr = 0;
    end
    rejet2 = rejet2+incr;
    
    %verification du test pour les instituts par acceptation de l hypothese
    if prop(2,1,i)<p1_0 + mu_alpha*ecart_type && prop(3,1,i)<p1_0 + mu_alpha*ecart_type && prop(4,1,i)<p1_0 + mu_alpha*ecart_type && prop(5,1,i)<p1_0 + mu_alpha*ecart_type && prop(6,1,i)<p1_0 + mu_alpha*ecart_type && prop(7,1,i)<p1_0 + mu_alpha*ecart_type
    cpt = cpt+1;
    end   
end

prop
rejet1
rejet2
cpt

end