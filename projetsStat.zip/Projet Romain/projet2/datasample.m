function [sample index_perm] = datasample(data, k)
	% datasample(data, k)
	%	This function returns a random sample from the matrix $data$.
	%	It randomly selects $k$ lines in the matrix. 
	% 
	%	/!\ $k$ must be less than the numbers of row in $data$
	%	
	%	PARAMETERS :
	%		- data : the matrix from which a sample must be extracted
	%		- k : the size of the sample
	%
	%	RETURN :
	%		- sample : the sample extracted
	%		- index_perm : the (row) indexes of the values extracted in $data$ 

	[len_x ~] = size(data);

	if(k >= len_x)
		error('The sample size ''k'' must be less than or equal to the number of line in the matrix');
    else
		index_perm = randi(len_x, k, 1);
		index_perm = sort(index_perm);
		sample = data(index_perm,:);
	end
end