// constructors
template<typename T> Set<T>::Set(const T array[], size_t len)
{
	// copy array elements to the internal set
	std::copy(array, array + len, std::inserter(internal_set, internal_set.begin()));
}

template<typename T> Set<T>::Set(const Set& s)
{
	internal_set = s.internal_set;
}

template<typename T> Set<T>::Set(const std::vector<T>& vec)
{
	// copy vector elements to the internal set
	std::copy(vec.begin(), vec.end(), std::inserter(internal_set, internal_set.begin()));
}

template<typename T> Set<T>::Set(const std::set<T>& s)
{
	internal_set = s;
}

template<typename T> void Set<T>::insert(const T& elem)
{
	internal_set.insert(elem);
}

template<typename T> void Set<T>::remove(const T& elem)
{
	internal_set.erase(elem);
}

// member operators
template<typename T> Set<T>& Set<T>::operator+=(const Set<T>& s)
{
	std::set<T> new_set; // temporary set in which the union will be inserted
	std::set_union(s.internal_set.begin(), s.internal_set.end(), internal_set.begin(), internal_set.end(), inserter(new_set, new_set.begin()));
	internal_set = new_set;
	return *this;
}

template<typename T> Set<T>& Set<T>::operator-=(const Set<T>& s)
{
	std::set<T> new_set; // temporary set in which the difference will be inserted
	std::set_difference(internal_set.begin(), internal_set.end(), s.internal_set.begin(), s.internal_set.end(), inserter(new_set, new_set.begin()));
	internal_set = new_set;
	return *this;
}

template<typename T> Set<T>& Set<T>::operator/=(const Set<T>& s)
{
	std::set<T> new_set; // temporary set in which the intersection will be inserted
	std::set_intersection(internal_set.begin(), internal_set.end(), s.internal_set.begin(), s.internal_set.end(), inserter(new_set, new_set.begin()));
	internal_set = new_set;
	return *this;
}

template<typename T> Set<T>& Set<T>::operator*=(const Set<T>& s)
{
	const_iterator set1_iter = internal_set.begin();
					
	std::set<T> new_set; // temporary set in which the inners products will be inserted

	while(set1_iter != internal_set.end()) // run through the internal set
	{
		const_iterator set2_iter = s.internal_set.begin();
		while(set2_iter != s.internal_set.end()) // run through the set s
		{ 	
			// insert current inner product in the temporary set
			new_set.insert((*set1_iter) * (*set2_iter));
			set2_iter++;
		}
		set1_iter++;
	}

	internal_set = new_set;

	return *this;
}

template<typename T> Set<T>& Set<T>::operator=(const Set<T>& s)
{
	internal_set.clear();
	internal_set = s.internal_set;
	return *this;
}

template<typename T> bool operator==(const Set<T>& s1, const Set<T>& s2)
{
	if(&s1 == &s2)
		return true;

	if(s1.cardinality() != s2.cardinality()) 
		return false;

	if(s1.cardinality() > s2.cardinality())
		return std::equal(s2.internal_set.begin(), s2.internal_set.end(), s1.internal_set.begin());
	return std::equal(s1.internal_set.begin(), s1.internal_set.end(), s2.internal_set.begin());
}

template<typename T> bool operator!=(const Set<T>& s1, const Set<T>& s2)
{
	return !(s1 == s2);
}

template<typename T> bool operator<(const Set<T>& s1, const Set<T>& s2)
{
	if(s1.cardinality() >= s2.cardinality())
		return false;
	// check if s2 includes s1
	return std::includes(s2.internal_set.begin(), s2.internal_set.end(), 
						s1.internal_set.begin(), s1.internal_set.end());
}

template<typename T> bool operator>(const Set<T>& s1, const Set<T>& s2)
{
	return (s2 < s1);
}

template<typename T> bool operator<=(const Set<T>& s1, const Set<T>& s2)
{
	// check if s2 includes s1
	return std::includes(s2.internal_set.begin(), s2.internal_set.end(), 
					s1.internal_set.begin(), s1.internal_set.end());
}

template<typename T> bool operator>=(const Set<T>& s1, const Set<T>& s2)
{
	return (s2 <= s1);
}

template<typename T> Set<T> operator+(Set<T> s1, const Set<T>& s2)
{
	return (s1 += s2);
}

template<typename T> Set<T> operator-(Set<T> s1, const Set<T>& s2)
{
	return (s1 -= s2);
}

template<typename T> Set<T> operator/(Set<T> s1, const Set<T>& s2)
{
	return (s1 /= s2);
}

template<typename T> std::ostream& operator<<(std::ostream& out, const Set<T>& s)
{
	typedef typename Set<T>::const_iterator cst; // iterator type to run through the internal container
	for(cst i = s.internal_set.begin(); i != s.internal_set.end(); i++)
		out << *i << " ";
	return out;
}
