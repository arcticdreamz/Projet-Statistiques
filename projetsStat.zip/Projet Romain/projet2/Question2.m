% Question 2
clear all; close all;
% Chargement des donnees
s_score = load('stat_data.mat');
score = s_score.m;
clear s_score;

final_score = mean(score.').';
real_mean = mean(final_score);
real_std = std(final_score, 1);
sample_size = 20;
nb_samples = 7;
nb_probe = 100;

% Extraction des echantillons (n = 20)
samples = zeros(nb_probe, nb_samples, sample_size);
for i = 1:nb_probe
    for j = 1:nb_samples
        samples(i,j,:) = datasample(final_score, sample_size);
    end
end

% Question 2.a
% caclcul de la valeur limite permettant la verification de l'hyptothese
n = sample_size;
alpha = 0.05;
p_hypothesis = 0.25;

epsilon = sqrt(p_hypothesis * (1 - p_hypothesis)/n) * ...
            norminv(1 - alpha, 0, 1);

p_limit = p_hypothesis + epsilon;

% passage a une variable de Bernoulli
grades_less_than_10 = (samples < 10);
prop_less_than_10 = zeros(nb_probe, nb_samples);

% calcul du pourcentage d'eleves ayant moins de 10/20 pour chaque
% echantillon
for i = 1:nb_probe
    for j = 1:nb_samples
        prop_less_than_10(i,j) = length(find(grades_less_than_10(i,j,:)))/sample_size;
    end
end
rejet_H0 = prop_less_than_10 >= p_limit;

% Question 2.a
nb_rejet_ulg = length(find(rejet_H0(:,1)));
p_rejet_ulg = nb_rejet_ulg/nb_probe;

% Question 2.b
nb_publi = length(find(any(rejet_H0(:,2:7).').'));
