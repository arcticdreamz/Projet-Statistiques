#include "Set.hpp"
#include "PairSet.hpp"

#include <iostream>

using namespace std;

int main()
{
	// test constructors
	set<char> real_set;
	vector<char> vec;

	real_set.insert('x'); vec.push_back('h');
	real_set.insert('y'); vec.push_back('f');
	real_set.insert('j'); vec.push_back('a');
	real_set.insert('a'); vec.push_back('j');
	real_set.insert('w'); vec.push_back('p');

	char array[5] = {'a', 'a', 'h', 'c', 'b'};

	Set<char> s1, s2(real_set), s3(vec), s4(array, 5);

	cout << "********************************" << endl;
	cout << "*         Test 'char'          *" << endl;
	cout << "********************************" << endl << endl;

	cout << "* Constructors" << endl;
	cout << "     - s1 : default" << endl;
	cout << "     - s2 : from set => ['a', 'j', 'w', 'x', 'y']" << endl;
	cout << "     - s3 : from std::vector => ['h', 'f', 'a', 'j', 'p']" << endl;
	cout << "     - s4 : from basic array => ['a', 'a', 'h', 'c', 'b']" << endl << endl;

	cout << "     - s1 : " << s1 << endl;
	cout << "     - s2 : " << s2 << endl;
	cout << "     - s3 : " << s3 << endl;
	cout << "     - s4 : " << s4 << endl << endl;

 	cout << "* isEmpty() : " << endl;
	cout << "     - s1 : " << s1.isEmpty() << endl;
	cout << "     - s2 : " << s2.isEmpty() << endl;
	cout << "     - s3 : " << s3.isEmpty() << endl;
	cout << "     - s4 : " << s4.isEmpty() << endl << endl;

	cout << "* cardinality() : " << endl;
	cout << "     - s1 : " << s1.cardinality() << endl;
	cout << "     - s2 : " << s2.cardinality() << endl;
	cout << "     - s3 : " << s3.cardinality() << endl;
	cout << "     - s4 : " << s4.cardinality() << endl << endl;

	s1.insert('r'); s1.insert('s'); s1.insert('t'); s1.insert('a');
	s2.insert('r'); s2.insert('s'); s2.insert('t'); s2.insert('a');
	s3.insert('r'); s3.insert('s'); s3.insert('t'); s3.insert('a');
	s4.insert('r'); s4.insert('s'); s4.insert('t'); s4.insert('a');

	cout << "* insert() : " << endl;
	cout << "     - elements : 'r', 's', 't', 'a'" << endl << endl;
	cout << "  Results : " << endl;
	cout << "     - s1 : " << s1 << endl;
	cout << "     - s2 : " << s2 << endl;
	cout << "     - s3 : " << s3 << endl;
	cout << "     - s4 : " << s4 << endl << endl;

	s1.remove('a'); s1.remove('z');
	s2.remove('a');	s2.remove('z');
	s3.remove('a');	s3.remove('z');
	s4.remove('a');	s4.remove('z');

	cout << "* remove() " << endl;
	cout << "     - elements : 'a', 'z' " << endl << endl;
	cout << "  Results : " << endl;
	cout << "     - s1 : " << s1 << endl;
	cout << "     - s2 : " << s2 << endl;
	cout << "     - s3 : " << s3 << endl;
	cout << "     - s4 : " << s4 << endl << endl;


	// test member operators
	char carray1[6] = {'r', 'o', 'm', 'a', 'i', 'n'};
	Set<char> s5(carray1, 6);

	cout << "* Member operators :" << endl;
	cout << "      - s1 += s5" << endl;
	cout << "      - s2 -= s5" << endl;
	cout << "      - s3 /= s5" << endl;
	cout << "      - s4 *= s5" << endl;
	cout << "  with :" << endl;
	cout << "      - s5 : " << s5 << endl;
	cout << "      - s1, s2, s3, s4 : see above" << endl << endl;
	cout << "  Results : " << endl;
	cout << "      - s1 (+=) : " << (s1 += s5) << endl;
	cout << "      - s2 (-=) : " << (s2 -= s5) << endl;
	cout << "      - s3 (/=) : " << (s3 /= s5) << endl;
	cout << "      - s4 (*=) : " << (s4 *= s5) << endl << endl;

	// test non-member operation
	Set<char> s6 = s1 + s2,
				s7 = s1 - s2,
				s8 = s1 / s2;

	cout << "* Non member operators : " << endl;
	cout << "      - s6 = s1 + s2 " << endl;
	cout << "      - s7 = s1 - s2 " << endl;
	cout << "      - s8 = s1 / s2 " << endl;
	cout << "      - s9 = s1 * s2 " << endl;
	cout << "  with : " << endl;
	cout << "      - s1 : " << s1 << endl;
	cout << "      - s2 : " << s2 << endl << endl;
	cout << "  Results : " << endl;
	cout << "      - s6 : " << s6 << endl;
	cout << "      - s7 : " << s7 << endl;
	cout << "      - s8 : " << s8 << endl;
	cout << "      - s9 : " << s1 * s2 << endl << endl;

	Set<char> s10 = s6;
	// test comparison operators
	cout << "* Comparison operators with : " << endl;
	cout << "      - s1  : " << s1 << endl;
	cout << "      - s6  : " << s6 << endl;
	cout << "      - s7  : " << s7 << endl;
	cout << "      - s10 : " << s10 << " (equals to s6)" << endl << endl;
	cout << "  Results : " << endl;
	cout << "      - s6 == s1  : " << (s6 == s1) << endl;
	cout << "      - s6 != s1  : " << (s6 != s1) << " (expected : opposite of previous) " << endl;
	cout << "      - s7 <  s1  : " << (s7 < s1) << endl;
	cout << "      - s1 >  s7  : " << (s1 > s7) << " (expected : same as previous) " << endl;
	cout << "      - s6 >  s1  : " << (s6 > s1) << endl;
	cout << "      - s6 >= s1  : " << (s6 >= s1) << " (expected : 1 if previous is 1) " << endl;
	cout << "      - s1 <= s6  : " << (s1 <= s6) << " (expected : same as previous) " << endl;
	cout << "      - s7 <= s1  : " << (s7 <= s1) << endl;
	cout << "      - s7 >= s1  : " << (s7 >= s1) << endl;
	cout << "      - s10 == s6 : " << (s10 == s6) << " (expected : 1) " << endl;
	cout << "      - s10 != s6 : " << (s10 != s6) << " (expected : 0) " << endl;
	cout << "      - s10 <  s6 : " << (s10 < s6) << " (expected : 0) " << endl;
	cout << "      - s10 >  s6 : " << (s10 > s6) << " (expected : 0) " << endl;
	cout << "      - s10 <= s6 : " << (s10 <= s6) << " (expected : 1) " << endl;
	cout << "      - s10 >= s6 : " << (s10 >= s6) << " (expected : 1) " << endl << endl;

	cout << "* Concatenation of operation with : " << endl;
	cout << "      - s1 + s2 - s7" << endl;
	cout << "      - s5 - s7 / s3" << endl;
	cout << "      - (s5 + s2) * s3" << endl;
	cout << "  with" << endl;
	cout << "      - s1 : " << s1 << endl;
	cout << "      - s2 : " << s2 << endl;
	cout << "      - s3 : " << s3 << endl;
	cout << "      - s5 : " << s5 << endl;
	cout << "      - s6 : " << s6 << endl;
	cout << "      - s7 : " << s7 << endl << endl;  
	cout << "  Results : " << endl;
	cout << "      - s1 + s2 - s7   : " << (s1 + s2 - s7) << endl;
	cout << "      - s5 - s7 / s3   : " << (s5 - s7 / s3) << endl;
	cout << "      - (s5 + s2) * s3 : " << ((s5 + s2) * s3) << endl << endl;

	// test string
	cout << "********************************" << endl;
	cout << "*        Test 'string'         *" << endl;
	cout << "********************************" << endl << endl;

	std::string strings[5] = {"I'm", "testing", "my", "Set<T>", "class"};
	std::string strings2[5] = {"Is", "it", "really", "really", "working"};
	Set<std::string> ss1(strings, 5), ss2(strings2, 5);

	cout << "ss1 : " << ss1 << endl;
	cout << "ss2 : " << ss2 << endl << endl;

	cout << "* Cartesian product  (ss1 * ss2) : " << endl;
	cout << "      - " << ss1 * ss2 << endl << endl;

	cout << "* Union : " << endl;
	cout << "      - " << (ss1 += ss2) << endl << endl;

	// cout << (ss1 *= ss2) << endl; //won't compile because the operator * is not defined for strings

	cout << "********************************" << endl;
	cout << "*         Test 'int'           *" << endl;
	cout << "********************************" << endl << endl;

	int iarray1[5] = {2, 5, 8, 9, 4};
	int iarray2[3] = {3, 8, 2};

	Set<int> sint1(iarray1, 5), sint2(iarray2, 3);

	cout << "sint1 : " << sint1 << endl;
	cout << "sint2 : " << sint2 << endl;
	cout << " *=   : " << (sint2 *= sint1) << endl << endl;

	cout << "********************************" << endl;
	cout << "*        Test 'float'          *" << endl;
	cout << "********************************" << endl << endl;

	float farray[4] = {25.2, 23.5, 852.2, 612.2};
	float farray2[5] = {123.0, 546.35, 674.741,98452.548, 6163.475};

	Set<float> sf1(farray, 4), sf2(farray2, 5);

	cout << "sf1 (" << sf1.cardinality() << ") : " << sf1 << endl;
	cout << "sf2 (" << sf2.cardinality() << ") : " << sf2 << endl;
	cout << "sf1 + sf2 (" << (sf1 + sf2).cardinality() << ") : " << (sf1 + sf2) << endl << endl;

	cout << "********************************" << endl;
	cout << "* Test 'PairSet' w/ dif. types *" << endl;
	cout << "********************************" << endl << endl;

	cout << "  Type 1 : int (sint1) " << endl;
	cout << "  Type 2 : char (s5) " << endl;

	cout << "  Cart. product : " << sint1 * s5 << endl;
	return 0;
}

