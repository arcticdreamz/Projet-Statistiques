#ifndef CLASS_SET_HPP_DEFINED
#define CLASS_SET_HPP_DEFINED

#include <cstddef>
#include <vector>
#include <set>
#include <algorithm>
#include <iostream>

template<typename S, typename U> class PairSet;

template<typename T> class Set
{
	// types 
	typedef typename std::set<T>::const_iterator const_iterator;
	typedef typename std::set<T>::iterator iterator;

	// friend functions
	template<typename S> friend std::ostream& operator<<(std::ostream&, const Set<S>&);
	template<typename S> friend bool operator==(const Set<S>&, const Set<S>&);
	template<typename S> friend bool operator<(const Set<S>&, const Set<S>&);
	template<typename S> friend bool operator<=(const Set<S>&, const Set<S>&);
	template<typename S, typename U> friend PairSet<S,U>::PairSet(const Set<S>& s1, const Set<U>& s2);

public:
	// constructor
	Set() { };
	Set(const T[], size_t);
	Set(const Set<T>&);
	Set(const std::vector<T>&);
	Set(const std::set<T>&);

	// destructor
	// the default constructor is synthesized by the compiler

	// member functions
	void insert(const T&);
	void remove(const T&);
	bool isEmpty() const { return internal_set.empty(); };
	size_t cardinality() const { return internal_set.size(); };

	// operator
	Set& operator+=(const Set&);
	Set& operator-=(const Set&);
	Set& operator/=(const Set&);
	Set& operator*=(const Set&);
	Set& operator=(const Set&);

private:
	std::set<T> internal_set;
};

#include "Set.cpp" // include template code

#endif

