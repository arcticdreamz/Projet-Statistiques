% Question 1
% Chargement des donnees
s_score = load('stat_data.mat');
score = s_score.m;
clear s_score;

final_score = mean(score.').';
real_mean = mean(final_score);
real_std = std(final_score, 1);
sample_size = 20;
nb_samples = 100;

% Extraction des echantillons (n = 20)
samples = zeros(sample_size, nb_samples);
for i=1:nb_samples
    samples(:,i) = datasample(final_score, sample_size);
end

% Question 1a 
sample_means = mean(samples);
sample_means_mean  = mean(sample_means);
sample_means_biais = sample_means_mean - real_mean;
sample_means_var   = var(sample_means);

% Question 1b
sample_medians = median(samples);
sample_medians_mean  = mean(sample_medians);
sample_medians_biais = sample_medians_mean - real_mean;
sample_medians_var   = var(sample_medians);

% Question 1c
sample_size_2 = 50;
samples50 = zeros(sample_size_2, 50);
for i=1:nb_samples
    samples50(:,i) = datasample(final_score, sample_size_2);
end

sample50_means = mean(samples50);
sample50_means_mean  = mean(sample50_means);
sample50_means_biais = sample50_means_mean - real_mean;
sample50_means_var   = var(sample50_means);

sample50_medians = median(samples50);
sample50_medians_mean  = mean(sample50_medians);
sample50_medians_biais = sample50_medians_mean - real_mean;
sample50_medians_var   = var(sample50_medians);

% Question 1d
alpha = 0.05;
n = sample_size;

% Question 1d.i
t =tinv(1 - alpha/2, n - 1);
u = norminv(1- alpha/2, 0, 1);
std_samples = std(samples);
IC_95_student = ([sample_means; sample_means] + ...
                    [-std_samples; std_samples] .* (t/sqrt(n))).';

% Question 1d.ii
% on utilise les echantillons extrait avant de la question 1a
IC_95_gauss = ([sample_means; sample_means] + ...
                    [-std_samples; std_samples] .* (u/sqrt(n))).';

% compteur du nombre d'intervalle contenant la moyenne
gauss_cnt = length(find((IC_95_gauss(:,1) <= real_mean) & (real_mean <= IC_95_gauss(:,2))));
student_cnt = length(find((real_mean >= IC_95_student(:,1)) & (real_mean <= IC_95_student(:,2))));
