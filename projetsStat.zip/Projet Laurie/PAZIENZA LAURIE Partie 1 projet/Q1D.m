function moyenne_theorie = Q1D

resultats=xlsread('Proba1ereSession20132014.xls'); %r�cup�ration des donn�es Excel

%Calcul des moyennes :

moyenne_theorie = (resultats(:,4) + resultats(:,5) + resultats(:,6))/3;
moyenne_exercices = (resultats(:,7) + resultats(:,8) + resultats(:,9))/3;

%Polygones des fr�quences cumul�es : 

cdfplot(moyenne_theorie);
xlabel('Points');
ylabel('Fr�quences cumul�es');
title('Polygone des fr�quences cumul�es pour la th�orie');

figure
cdfplot(moyenne_exercices);
xlabel('Points');
ylabel('Fr�quences cumul�es');
title('Polygone des fr�quences cumul�es pour les exercices');
end

