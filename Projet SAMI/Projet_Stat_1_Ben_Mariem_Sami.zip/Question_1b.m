function Question_1b
resultats=xlsread('Proba1ereSession20152016.xls');%r�cup�ration des donn�es

ex1=resultats(:,7); %Stockage des r�sultats de l'exercice 1
ex2=resultats(:,8); %Stockage des r�sultats de l'exercice 2
ex3=resultats(:,9); %Stockage des r�sultats de l'exercice 3

%Calcul de La Moyenne gr�ce � la fonction "mean" pr�-impl�ment�e dans Matlab.

moy1 = mean(ex1)
moy2 = mean(ex2)
moy3 = mean(ex3)

%Calcul des M�dianes gr�ce � la fonction "median" pr�-impl�ment�e dans Matlab.

med1 = median(ex1)
med2 = median(ex2)
med3 = median(ex3)

%Calcul des Modes gr�ce � la fonction "mode" pr�-impl�ment�e dans Matlab.

mode1 = mode(ex1)
mode2 = mode(ex2)
mode3 = mode(ex3)

%Calcul des �carts types gr�ce � la fonction "std" pr�-impl�ment�e dans Matlab.

ecart_type1 = std(ex1)
ecart_type2 = std(ex2)
ecart_type3 = std(ex3)

%Calculons les bornes d'un r�sulat dit "normal".

min_ex1 = moy1 - ecart_type1;
min_ex2 = moy2 - ecart_type2;
min_ex3 = moy3 - ecart_type3;

max_ex1 = moy1 + ecart_type1;
max_ex2 = moy2 + ecart_type2;
max_ex3 = moy3 + ecart_type3;

%D�terminons la proportion d'�l�ve normaux.

prop_ex1 =0;
prop_ex2 =0;
prop_ex3 =0;

nbre_etudiants = max(size(resultats));

for i=1:nbre_etudiants
   
    if ex1(i)>=min_ex1 && ex1(i)<=max_ex1 % On d�termine si oui ou non un r�sultat est dans l'intervalle des resultats "normaux".
        prop_ex1=prop_ex1 + 1;
    end    
     
    if ex2(i)>=min_ex2 && ex2(i)<=max_ex2% On d�termine si oui ou non un r�sultat est dans l'intervalle des resultats "normaux".
        prop_ex2=prop_ex2 + 1;
    end    
     
    if ex3(i)>=min_ex3 && ex3(i)<=max_ex3% On d�termine si oui ou non un r�sultat est dans l'intervalle des resultats "normaux".
        prop_ex3=prop_ex3 + 1;
    end
end

    prop_ex1 = (prop_ex1/nbre_etudiants)*100
    prop_ex2 =(prop_ex2/nbre_etudiants)*100
    prop_ex3 =(prop_ex3/nbre_etudiants)*100
    

end