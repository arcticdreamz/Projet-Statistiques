function Question_1e

resultats=xlsread('Proba1ereSession20152016.xls'); %r�cup�ration des donn�es

%Nous r�alisons le "Scatterplot" gr�ce � la fonction "scatter" pr�-impl�ment�e dans Matlab

%Nous allons gr�ce � ce graphe pouvoir comparer les r�sultats du Projet 2 � ceux du r�sultats de la Question-Projet.
scatter(resultats(:,2), resultats(:,3));
xlabel('R�sultats du projet 2');
ylabel('R�sultats de la Question sur le projet 2');
title('Scatterplot comparant les r�sultats obtenu au projet 2 et ceux obtenu � la question sur le projet 2');

%Calcul du Coefficient de Corr�lation.
Matrice_de_Correl = corrcoef(resultats(:,2), resultats(:,3))
Coeff_de_Correl = Matrice_de_Correl(1,2)

end