function Question_1a

    resultats = xlsread('Proba1ereSession20152016.xls'); %recuperation des donnees. 

    x = 0:20;

    hist(resultats(:,4), x); %Nous tra�ons l'histogramme des donnees que nous avons recupere.
    set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]); % commande pour afficher toutes les graduations
    xlabel('Cote Obtenue sur 20');
    ylabel('Nombre d etudiants');
    title('Histogramme de la Question 1 de theorie');

    figure
    hist(resultats(:,5), x); %Nous tra�ons l'histogramme des donnees que nous avons recupere.
    set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]);
    xlabel('Cote Obtenue sur 20');
    ylabel('Nombre d etudiants');
    title('Histogramme de la Question 2 de theorie');

    figure
    hist(resultats(:,6), x); %Nous tra�ons l'histogramme des donnees que nous avons recupere.
    set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]); % commande pour afficher toutes les graduations
    xlabel('Cote Obtenue sur 20');
    ylabel('Nombre d etudiants');
    title('Histogramme de la Question 3 de theorie');

end