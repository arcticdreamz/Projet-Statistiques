function moy_theorie = Question_1d(i)
%L'argument "i" nous dit si on veut afficher les graphiques ou non ! 
% i = false --> On affiche pas les graphiques
% i = true --> On affiche les graphiques


resultats=xlsread('Proba1ereSession20152016.xls'); %r�cup�ration des donn�es

%Calcul des moyennes relatives aux cotes de th�orie et d'exercices.

moy_theorie = mean(resultats(:,4:6),2);
moy_exercice = mean(resultats(:,7:9),2);

%G�n�rons le Polyg�ne des fr�quences cumul�es gr�ce � la fonction "cdfplot" pr�-impl�ment�e dans Matlab.

if(i == true) %si On veut les graphiques
    figure
    cdfplot(moy_theorie);
    xlabel('Cote Obtenue sur 20');
    ylabel('Fr�quences cumul�es');
    title('Polygone des fr�quences cumul�es de la Th�orie');

    figure
    cdfplot(moy_exercice);
    xlabel('Cote Obtenue sur 20');
    ylabel('Fr�quences cumul�es');
    title('Polygone des fr�quences cumul�es des Exercices');
end

end