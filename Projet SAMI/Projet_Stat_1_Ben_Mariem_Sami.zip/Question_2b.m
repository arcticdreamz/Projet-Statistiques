function Question_2b

resultats=xlsread('Proba1ereSession20152016.xls'); %r�cup�ration des donn�es

Freq_Pop_ex1 = cdfcalc(resultats(:,7));
Freq_Pop_ex2 = cdfcalc(resultats(:,8));
Freq_Pop_ex3 = cdfcalc(resultats(:,9));

%Nous allons ici d�terminer les echantillons sur lesquelles nous allons travailler
%et ensuite d�terminer la moyenne, la m�diane, l'�cart-type et la distance
%de Kolmogorov pour les diff�rents exercices. 
for m = 1:100
    rand_vec = randsample (127, 20, true);%Nous d�terminons les positions dans 
    %le vecteur des r�sulats que nous allons prendre dans notre �chantillon.

    ech_ex1 = resultats(rand_vec, 7);%�chantillon de r�sulats � l'exercice 1.
    ech_ex2 = resultats(rand_vec, 8);%�chantillon de r�sulats � l'exercice 2.
    ech_ex3 = resultats(rand_vec, 9);%�chantillon de r�sulats � l'exercice 3.

    moy_ex1(m) = mean(ech_ex1);%Moyenne d'un �chantillon de r�sulats de l'exercice 1
    median_ex1(m) = median(ech_ex1);%M�diane d'un �chantillon de r�sulats de l'exercice 1
    ecart_ex1(m) = std(ech_ex1,1);%Ecart-type d'un �chantillon de r�sulats de l'exercice 1

    Freq_Ech_ex1 = cdfcalc(ech_ex1) ;
    Freq_Ech_ex2 = cdfcalc(ech_ex2) ;
    Freq_Ech_ex3 = cdfcalc(ech_ex3) ;

    %Calcul des distances de Kolmogorov Smirnov des diff�rents 
    [~, ~, kolmo1]=kstest2(Freq_Ech_ex1, Freq_Pop_ex1);
    dist_kolmo_ex1(m)=kolmo1;
    [~, ~, kolmo2]=kstest2(Freq_Ech_ex2, Freq_Pop_ex2);
    dist_kolmo_ex2(m)=kolmo2;
    [~, ~, kolmo3]=kstest2(Freq_Ech_ex3, Freq_Pop_ex3);
    dist_kolmo_ex3(m)=kolmo3;

end

%Affichage des Histogrammes gr�ce � la fonction "hist" pr�-impl�ment�e dans
%Matlab.
x = 0:20;
%Histogramme des moyennes
figure
hist(moy_ex1,x);
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]);
title('Histogramme des moyennes des r�sultats de l exercice 1 pour les 100 �chantillons.')
ylabel('Fr�quences des moyennes')
xlabel('Moyenne Ex1 ')

%Moyenne de la moyenne

moy_moy=mean(moy_ex1)

%Histogramme des m�dianes
figure
hist(median_ex1,x);
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]);
title('Histogramme des m�dianes des r�sultats de l exercice 1 pour les 100 �chantillons.')
ylabel('Fr�quences des m�dianes')
xlabel('M�diane Ex1')

%Moyenne de la m�diane 

moy_med=mean(median_ex1)

%Histogramme des �carts-types
figure
hist(ecart_ex1,x);
set(gca,'xtick',[0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20]);
title('Histogramme des �carts types r�sultats de l exercice 1 pour les 100 �chantillons.')
ylabel('Fr�quences des �carts-types')
xlabel('�carts-types Ex1')

%Moyenne de l'�cart-type 

moy_ecart=mean(ecart_ex1)

%Affichage des Histogrammes de distances de Kolmogorov Smirnov calcul�es
%pr�c�demment.

figure
hist(dist_kolmo_ex1, 21)
title('Histogramme des distances de Kolmogrorov pour l exercice 1')
ylabel('Nombre d �chantillons')
xlabel('Distance de Kolomogorov')

figure
hist(dist_kolmo_ex2, 21)
title('Histogramme des distances de Kolmogrorov pour l exercice 2')
ylabel('Nombre d �chantillons')
xlabel('Distance de Kolomogorov')

figure
hist(dist_kolmo_ex3, 21)
title('Histogramme des distances de Kolmogrorov pour l exercice 3')
ylabel('Nombre d �chantillons')
xlabel('Distance de Kolomogorov')

end