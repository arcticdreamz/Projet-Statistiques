function Question_2a

resultats=xlsread('Proba1ereSession20152016.xls'); %r�cup�ration des donn�es

%Question 2. a)
%echantillon = randsample(127,20,true); %Position de l'Echantillon aleatoire de 20 �tudiants.

echantillon = [ 40 ; 118 ; 55 ; 24 ; 115 ; 125 ; 56 ; 15 ; 33 ; 52 ; 76 ; 34 ; 77 ; 91 ; 29 ; 15 ; 38 ; 41 ; 54 ; 65 ; ];

proj1=resultats(echantillon,1);
proj2=resultats(echantillon,2);
qproj2=resultats(echantillon,3);

theorie1=resultats(echantillon,4); 
theorie2=resultats(echantillon,5);
theorie3=resultats(echantillon,6);

ex1 =resultats(echantillon,7); 
ex2 =resultats(echantillon,8);
ex3=resultats(echantillon,9);

%Question 2. a) i.

%Calcul des moyennes :

moy_ex1 = mean(ex1)
moy_ex2 = mean(ex2)
moy_ex3 = mean(ex3)
    
%Calcul des m�dianes :

med_ex1 = median(ex1)
med_ex2 = median(ex2)
med_ex3 = median(ex3)
    
%Calcul des �cart-types:

ecart_type_ex1 = std(ex1)
ecart_type_ex2 = std(ex2)
ecart_type_ex3 = std(ex3)

%Question 2. a) ii.

%Affichage des Boites � Moustaches

boxplot(proj1);
title('Boite � Moustache des r�sultats du Projet 1');

figure
boxplot(proj2);
title('Boite � Moustache des r�sultats du Projet 2 ');

figure
boxplot(qproj2);
title('Boite � Moustache des r�sultats de la Question-Projet');

%Question 2. a) iii.

%Cr�ation de la variable repr�sentant la moyenne de chaque �tudiant pour la th�orie
moy_theorie = (theorie1(:) + theorie2(:) + theorie3(:))/3

%Polygone des fr�quences cumul�es de la moyenne de chaque �tudiant pour la
%th�orie sur un echantillon de 20 �tudiants pris al�atoirement.

figure
cdfplot(moy_theorie);
xlabel('Cote Obtenue sur 20');
ylabel('Fr�quences cumul�es');
title('Polygone des fr�quences cumul�es pour la th�orie de l echantillon');

%R�cup�ration de la moyenne de chaque �tudiant pour la th�orie d'un
%population.

moy_theorie_popu = Question_1d(false);

%Polygone des fr�quences cumul�es de la moyenne de chaque �tudiant pour la
%th�orie sur toute la population.

figure
cdfplot(moy_theorie_popu);
xlabel('Cote Obtenue sur 20');
ylabel('Fr�quences cumul�es');
title('Polygone des fr�quences cumul�es pour la th�orie de la population');


%Comparaison des fr�quences cumul�es de la moyenne de chaque �tudiant pour
%la th�orie de l'echantillon d'une part et de la population d'autres parts.

figure 
cdfplot(moy_theorie);

hold on 
h=cdfplot(moy_theorie_popu);
legend('Echantillon','Population');
set(h,'color','r')
xlabel('Points');
ylabel('Fr�quences cumul�es');
title('Polygones des fr�quences cumul�es pour la th�orie de l �chantillon et pour la population');

%Calcul de la distance de Kolmogorov Smirnov gr�ce � la fonction
%pr�-impl�ment�e dans MATLAB "ktest2".

[~, ~, Kolmo] = kstest2(moy_theorie_popu, moy_theorie);

distKolmo = max(Kolmo)


end

