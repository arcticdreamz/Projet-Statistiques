function Question_1c

resultats=xlsread('Proba1ereSession20152016.xls'); %r�cup�ration des donn�es

%Affichage des boites � moustche gr�ce � la fonction "boxplot" pr�-impl�ment�e dans Matlab.

boxplot(resultats(:,1));
title('Boite � Moustache du Projet 1');

figure
boxplot(resultats(:,2));
title('Boite � Moustache du Projet 2');

figure
boxplot(resultats(:,3));
title('Boite � Moustache de la Question relative au Projet 2');

%Calcul des Quartiles gr�ce � la fonction "quantile" pr�-impl�ment�e dans
%Matlab.

quartiles1 = quantile(resultats(:,1), [.25 .50 .75]) 
quartiles2 = quantile(resultats(:,2), [.25 .50 .75])
quartiles_qprojet = quantile(resultats(:,3), [.25 .50 .75])

end