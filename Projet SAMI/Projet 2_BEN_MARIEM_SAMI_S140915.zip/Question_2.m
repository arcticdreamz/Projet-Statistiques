% Question 2 : Test d'hypoth�se

resultats = xlsread('Proba1ereSession20152016.xls'); %recuperation des donn�es. 
[col lig] = size(resultats);

%Calcul des notes finales des �tudiants
for i = 1:col
    final_results(i) = mean(resultats(i,:));
end

%Cr�ation de 7 �chantillons de taille 20 (on tire 100 fois 7 �chantillons
%de cette taille).
taille_ech = 20;
nb_org = 7;
prop = zeros(7,100);
u = 1.645;

rejet_ULG = 0;
rejet_Instituts = 0;
nb_publi = 0;
A = 0;

for i = 1:100
    
    for j = 1:nb_org
        
        pos_ech(:,i,j) = randsample(col,20,1);
        for k = 1:taille_ech 
            
            echantillon(k,i,j) = final_results(pos_ech(k,i,j));
            
            %Recherche de la proportion en dessous de 10
            if echantillon(k,i,j) < 10
                prop(j,i) = prop(j,i) + 1/taille_ech;
            end    
        end
    end
    
    %a) Test d'hypoth�ses pour les autorit�s de l'ULG
    if prop(1,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20))
        rejet_ULG = rejet_ULG + 1;
    end
    
    %b) Test d'hypoth�ses pour les institus en vue de la publication ou non
    %d'un article. 
    
    if prop(2,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20)) || prop(3,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20)) || prop(4,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20)) || prop(5,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20)) || prop(6,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20)) || prop(7,i) > (1/4 + u*sqrt(1/4*(1-1/4)/20))
        rejet_Instituts = rejet_Instituts + 1;
        nb_publi = nb_publi+1;
    end
    
end

%disp('Nombre de rejets pour l Ulg')
rejet_ULG
%disp('Nombre de publications')        
nb_publi   
    