% Question 1 : Estimation 

%a) Creation d'une nouvelle variable m_X contenant les 100 valeurs des moyennes
%de chaque echantillon + Estimation du biais et de la variance de
%l'estimateur m_X de la note finale moyenne de la population.

resultats = xlsread('Proba1ereSession20152016.xls'); %recuperation des donnees. 

[col lig] = size(resultats);

%Calcul des notes finales des etudiants
for i = 1:col
    final_results(i) = mean(resultats(i,:));
end
taille_ech = 20;
%Creation des 100 echantillons de taille 20
for j = 1:100
    pos_ech(:,j) = randsample(col,20);
    for i=1:taille_ech
        %creation d'un echantillon de 20 personnes.
        echantillon1(i,j) = final_results(pos_ech(i,j));
    end
    %Creation de la nouvelle variable m_X
    m_X(j) = mean(echantillon1(:,j));
end

Vecteurs_Aleatoires = pos_ech;
Vec_Al = pos_ech;

moy_tot = mean(final_results)

%Calcul du biais et de la variance de la variable m_X
biais_moy = mean(m_X) - moy_tot
variance_moy = var(m_X,1)


%b) Creation d'une nouvelle variable median_X contenant les 100 valeurs des
%medianes de chaque echantillon + Estimation du biais et de la variance de
%l'estimateur median_X de la note finale moyenne de la population.

%Creation de la nouvelle variable median_X
for j = 1:100
    median_X(j) = median(echantillon1(:,j)); 
end

%Calcul du biais et de la variance de la variable median_X
biais_median = mean(median_X) - moy_tot
variance_median = var(median_X, 1)

%c) Nous reproduisons ce que nous avons fait pour des echantillons de 50
%personnes. 
taille_ech_2 = 50;

%Creation des 100 echantillons de taille 50
for j = 1:100
    pos_ech2(:,j) = randsample(col,50);
    for i=1:taille_ech_2
        %creation d'un echantillon de 50 personnes.
        echantillon2(i,j) = final_results(pos_ech2(i,j));
    end
    %Creation de la nouvelle variable m_X
    m_X2(j) = mean(echantillon2(:,j));
    %Creation de la nouvelle variable median_X
    median_X2(j) = median(echantillon2(:,j)); 
end

%Calcul du biais et de la variance de la variable m_X
biais_moy2 = mean(m_X2) - moy_tot
variance_moy2 = var(m_X2,1)

%Calcul du biais et de la variance de la variable median_X
biais_median2 = mean(median_X2) - moy_tot
variance_median2 = var(median_X2, 1)

%d) Construisons pour chaque echantillon de taille 20 un intervalle de
%confiance � 95% de la note finale moyenne de la population � partir de m_X
%en faisant l'hypothese que la variable parente est Gaussienne.


n_student = 0;
n_gauss = 0;
taille_ech = 20;

s_student_temp = zeros(1,100);

for j = 1:100
    
    for i = 1:taille_ech
        s_student_temp(j) = s_student_temp(j) + (echantillon1(i,j)-m_X(j))^2;
    end
    
    s_student(j) = sqrt(s_student_temp(j)/(taille_ech-1));
    s_gauss(j) = sqrt(var(echantillon1(:,j),1));

end

t = tinv(1 - 0.05/2 , taille_ech - 1);
u = norminv(1- 0.05/2, 0, 1);

for j = 1:100
    
    borne1_Ic_student(j) = m_X(j) - (t*s_student(j)/sqrt(taille_ech));
    borne2_Ic_student(j) = m_X(j) + (t*s_student(j)/sqrt(taille_ech));
    
    borne1_Ic_gauss(j) = m_X(j) - (u*s_gauss(j)/sqrt(taille_ech));
    borne2_Ic_gauss(j) = m_X(j) + (u*s_gauss(j)/sqrt(taille_ech));
    
    if moy_tot < borne2_Ic_student(j) && moy_tot > borne1_Ic_student(j)
        n_student = n_student+1;
    end
    
    if moy_tot < borne2_Ic_gauss(j) && moy_tot > borne1_Ic_gauss(j)
         n_gauss = n_gauss+1;
    end
end

n_student
n_gauss
