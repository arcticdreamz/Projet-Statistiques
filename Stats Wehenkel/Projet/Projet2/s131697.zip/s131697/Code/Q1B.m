%Ce script ecrit le biais et la variance de l'estimateur median_x sur 100
%�chantillons iid de 20 notes finales.
[biais, variance] = Q1Bf(20,100)