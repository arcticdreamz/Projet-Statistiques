%Ce script donne le biais et la variance de l'estimateur m_x sur 100
%�chantillons iid de 20 notes finales.
[biais, variance] = Q1Af(100, 20)