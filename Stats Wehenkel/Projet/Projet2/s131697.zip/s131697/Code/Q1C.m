%Cet script ecrit le biais et la variance de l'estimateur m_x et de l'estimateur median_x sur 100
%�chantillons iid de 50 notes finales.
[biais_mean, variance_mean] = Q1Af(100, 50)
[biais_median, variance_median] = Q1Bf(100, 50)
