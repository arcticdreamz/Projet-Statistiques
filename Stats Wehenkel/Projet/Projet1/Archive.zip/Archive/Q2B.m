function Q2B
%% Import the data
[~, ~, raw] = xlsread('/Users/antoinewehenkel/Documents/Ecole/2015-2016/Stats/Projet/Projet1/proba1ereSession20142015.xls','Donn�es');
raw = raw(2:end,:);

%% Create output variable
data = reshape([raw{:}],size(raw));

%% Allocate imported array to column variable names
Exercice1 = data(:,7);
Exercice2 = data(:,8);
Exercice3 = data(:,9);

%% Clear temporary variables
clearvars data raw;
%% I
%On g�n�re les moyennes de 100 �chantillons de 20 �l�ves pour l'exercice 1
nbr_sample = 100;
size_sample = 20;
sample_mean = zeros(nbr_sample,1);
sample_of_sample = zeros(size_sample, nbr_sample);

for j = 1 : nbr_sample
    
    sample = randsample(length(Exercice1), size_sample, true);
    sample_Exercice1 = zeros(1, size_sample);
    sample_Exercice2 = zeros(1, size_sample);
    sample_Exercice3 = zeros(1, size_sample);

    for i = 1 : size_sample
        sample_Exercice1(i) = Exercice1(sample(i));
        sample_Exercice2(i) = Exercice2(sample(i));
        sample_Exercice3(i) = Exercice3(sample(i));
    end
    
    sample_of_sample(:,j) = sample_Exercice1;
    sample_of_sample2(:,j) = sample_Exercice2;
    sample_of_sample3(:,j) = sample_Exercice3;
end
%On calcule les moyennes de 100 �chantillons
sample_mean = mean(sample_of_sample);

figure()
hist(sample_mean, 10)
title('Histogramme des moyennes des notes � la question d exercice 1 d �chantillon de 20 personnes')
ylabel('Nombre d  echantillon')
xlabel('Moyenne')

disp('moyenne des moyenne des �chantillons')
mean(sample_mean)
disp('moyenne de la population')
mean(Exercice1)

%% II
%On calcule la m�diane de chaque �chantillon(il y en a 100)
sample_median = median(sample_of_sample);

figure()
hist(sample_median, 10)
title('Histogramme des m�diane des notes � la question d exercice 1 d �chantillon de 20 personnes')
ylabel('Nombre d  echantillon')
xlabel('M�diane')

disp('moyenne des m�dianes des �chantillons')
mean(sample_median)


%% III
%On calcule l'ecart type de chaque �chanrillon
sample_et = std(sample_of_sample, 1);

figure()
hist(sample_et, 10)
title('Histogramme des �carts type des notes � la question d exercice 1 d �chantillon de 20 personnes')
ylabel('Nombre d  echantillon')
xlabel('Ecart type')

disp('moyenne des �carts type des �chantillons')
mean(sample_et)
disp('Ecarts type de la population')
std(Exercice1, 1)

%% IV
%On calcule la distance K-S entre chaque �chantillon et la population

%Ex 1
dist_ks = zeros(nbr_sample, 1);

for i = 1 : nbr_sample
    [~, ~, dist_ks(i)]=kstest2(Exercice1, sample_of_sample(:,i));
end
figure()
hist(dist_ks, 3)
title('Histogramme des distances de K-S des notes � la question d exercice 1 d �chantillon de 20 personnes')
ylabel('Nombre d  echantillon')
xlabel('Distance de K-S')

%Ex 2
dist_ks2 = zeros(nbr_sample, 1);

for i = 1 : nbr_sample
    [~, ~, dist_ks2(i)]=kstest2(Exercice2, sample_of_sample2(:,i));
end
figure()
hist(dist_ks2, 3)
title('Histogramme des distances de K-S des notes � la question d exercice 2 d �chantillon de 20 personnes')
ylabel('Nombre d  echantillon')
xlabel('Distance de K-S')

%Ex 3
dist_ks3 = zeros(nbr_sample, 1);

for i = 1 : nbr_sample
    [~, ~, dist_ks3(i)]=kstest2(Exercice3, sample_of_sample3(:,i));
end
figure()
hist(dist_ks3, 3)
title('Histogramme des distances de K-S des notes � la question d exercice 3 d �chantillon de 20 personnes')
ylabel('Nombre d  echantillon')
xlabel('Distance de K-S')
end

